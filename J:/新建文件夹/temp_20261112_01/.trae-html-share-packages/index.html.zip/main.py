"""圈圈语音社：FastAPI + SQLAlchemy + WebSocket 全功能本地后端。"""

import asyncio
import hashlib
import hmac
import json
import math
import os
import random
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import (
    Column, DateTime, Float, Integer, MetaData, String, Table, Text,
    UniqueConstraint, and_, case, create_engine, delete, desc, func,
    insert, or_, select, text, update,
)
from sqlalchemy.event import listens_for

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "circle_voice.db"
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DB_PATH.as_posix()}")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("mysql://"):
    DATABASE_URL = DATABASE_URL.replace("mysql://", "mysql+pymysql://", 1)

TOKEN_SECRET = os.getenv("TOKEN_SECRET", "circle_voice_local_secret_2026")
TOKEN_EXPIRE_HOURS = 72
STATIC_DIR = BASE_DIR

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
metadata = MetaData()

# 全局验证码存储（本地开发版）
phone_codes: dict[str, str] = {}
# 平台钱包 — 礼物收益分成中的 70% 归平台（本地内存计数器）
PLATFORM_WALLET = {"coins": 0}
# 管理员 token（简单硬编码，本地演示）
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "admin_local_2026")
# 管理员 openid（本地演示用）
ADMIN_OPENID = "admin_local_demo"


def require_admin(authorization: str = Header(default="")):
    """简易管理员鉴权：Bearer admin_token 或 openid 在 users 表里是管理员。"""
    token = (authorization or "").replace("Bearer ", "").strip()
    if token == ADMIN_TOKEN:
        return {"role": "admin", "mode": "token"}
    # 也允许本地开发用固定管理员 openid 登录
    with engine.connect() as conn:
        admin_user = fetch_one(conn, select(users).where(text("oauth_wechat_openid = :oid OR oauth_qq_openid = :oid OR oauth_apple_openid = :oid OR phone = :phone")).bindparams(oid=ADMIN_OPENID, phone="admin"))
        if admin_user:
            return {"role": "admin", "user_id": admin_user["id"]}
    raise HTTPException(status_code=403, detail="管理员权限不足")


@listens_for(engine, "connect")
def configure_sqlite(dbapi_connection, _):
    if engine.dialect.name != "sqlite":
        return
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.close()


users = Table(
    "users", metadata,
    Column("id", Integer, primary_key=True),
    Column("phone", String(32), unique=True),
    Column("nickname", String(80), nullable=False),
    Column("avatar", Text),
    Column("bio", Text),
    Column("gender", String(16), default="secret"),
    Column("age", Integer),
    Column("location", String(80)),
    Column("lat", Float), Column("lng", Float),
    Column("is_vip", Integer, default=0),
    Column("vip_expire", String(40)),
    Column("coins", Integer, default=128),
    Column("likes_count", Integer, default=0),
    Column("followers_count", Integer, default=0),
    Column("following_count", Integer, default=0),
    Column("created_at", DateTime, default=datetime.now),
)
matches = Table(
    "matches", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("target_id", Integer, nullable=False),
    Column("action", String(16), nullable=False),
    Column("matched", Integer, default=0),
    Column("created_at", DateTime, default=datetime.now),
)
circles = Table(
    "circles", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String(120), nullable=False),
    Column("icon", String(32)),
    Column("members", Integer, default=0),
    Column("created_at", DateTime, default=datetime.now),
)
posts = Table(
    "posts", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("content", Text),
    Column("image", Text),
    Column("location", String(80)),
    Column("circle_id", Integer),
    Column("likes", Integer, default=0),
    Column("comments", Integer, default=0),
    Column("created_at", DateTime, default=datetime.now),
)
voice_rooms = Table(
    "voice_rooms", metadata,
    Column("id", Integer, primary_key=True),
    Column("host_id", Integer, nullable=False),
    Column("topic", String(200), nullable=False),
    Column("category", String(60)),
    Column("listeners", Integer, default=0),
    Column("status", String(20), default="live"),
    Column("started_at", DateTime, default=datetime.now),
)
chat_conversations = Table(
    "chat_conversations", metadata,
    Column("id", Integer, primary_key=True),
    Column("user1_id", Integer, nullable=False),
    Column("user2_id", Integer, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("user1_id", "user2_id", name="uq_conversation_pair"),
)
chat_messages = Table(
    "chat_messages", metadata,
    Column("id", Integer, primary_key=True),
    Column("conversation_id", Integer, nullable=False),
    Column("sender_id", Integer, nullable=False),
    Column("content", Text, nullable=False),
    Column("msg_type", String(20), default="text"),
    Column("created_at", DateTime, default=datetime.now),
    Column("read", Integer, default=0),
)
notifications = Table(
    "notifications", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("from_user_id", Integer),
    Column("type", String(30), nullable=False),
    Column("content", Text),
    Column("is_read", Integer, default=0),
    Column("created_at", DateTime, default=datetime.now),
)
orders = Table(
    "orders", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("plan", String(40), nullable=False),
    Column("pay_method", String(30)),
    Column("amount", Float, nullable=False),
    Column("status", String(20), default="success"),
    Column("created_at", DateTime, default=datetime.now),
)
tasks = Table(
    "tasks", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("task_key", String(50), nullable=False),
    Column("completed", Integer, default=0),
    Column("reward", Integer),
    Column("created_at", DateTime, default=datetime.now),
)
post_likes = Table(
    "post_likes", metadata,
    Column("id", Integer, primary_key=True),
    Column("post_id", Integer, nullable=False),
    Column("user_id", Integer, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("post_id", "user_id", name="uq_post_like"),
)
post_comments = Table(
    "post_comments", metadata,
    Column("id", Integer, primary_key=True),
    Column("post_id", Integer, nullable=False),
    Column("user_id", Integer, nullable=False),
    Column("content", Text, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
)
follows = Table(
    "follows", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("target_id", Integer, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("user_id", "target_id", name="uq_follow_pair"),
)
user_blocks = Table(
    "user_blocks", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("blocked_id", Integer, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("user_id", "blocked_id", name="uq_user_block_pair"),
)
circle_members = Table(
    "circle_members", metadata,
    Column("id", Integer, primary_key=True),
    Column("circle_id", Integer, nullable=False),
    Column("user_id", Integer, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("circle_id", "user_id", name="uq_circle_member"),
)
room_messages = Table(
    "room_messages", metadata,
    Column("id", Integer, primary_key=True),
    Column("room_id", Integer, nullable=False),
    Column("user_id", Integer, nullable=False),
    Column("content", Text, nullable=False),
    Column("msg_type", String(20), default="text"),
    Column("gift_key", String(30)),
    Column("gift_name", String(50)),
    Column("gift_emoji", String(16)),
    Column("gift_count", Integer, default=0),
    Column("gift_price", Integer, default=0),
    Column("created_at", DateTime, default=datetime.now),
)
room_visits = Table(
    "room_visits", metadata,
    Column("id", Integer, primary_key=True),
    Column("room_id", Integer, nullable=False),
    Column("user_id", Integer, nullable=False),
    Column("visited_on", String(10), nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("room_id", "user_id", "visited_on", name="uq_room_visit_day"),
)
wallet_transactions = Table(
    "wallet_transactions", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("kind", String(30), nullable=False),
    Column("amount", Float, default=0),
    Column("coins", Integer, default=0),
    Column("note", String(200)),
    Column("created_at", DateTime, default=datetime.now),
)
task_claims = Table(
    "task_claims", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("task_key", String(40), nullable=False),
    Column("claim_date", String(10), nullable=False),
    Column("reward", Integer, nullable=False),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("user_id", "task_key", "claim_date", name="uq_task_claim_day"),
)

# ---------- 好感度系统 ----------
user_favorites = Table(
    "user_favorites", metadata,
    Column("id", Integer, primary_key=True),
    Column("from_user_id", Integer, nullable=False),
    Column("to_user_id", Integer, nullable=False),
    Column("value", Integer, default=0),
    Column("gifts_sent", Integer, default=0),
    Column("gifts_received", Integer, default=0),
    Column("chat_days", Integer, default=0),
    Column("voice_days", Integer, default=0),
    Column("updated_at", DateTime, default=datetime.now),
    Column("created_at", DateTime, default=datetime.now),
    UniqueConstraint("from_user_id", "to_user_id", name="uq_favorites_pair"),
)

user_relationships = Table(
    "user_relationships", metadata,
    Column("id", Integer, primary_key=True),
    Column("user1_id", Integer, nullable=False),
    Column("user2_id", Integer, nullable=False),
    Column("rel_type", String(20), nullable=False),   # couple / bestie / bro / confidant
    Column("favorability", Integer, default=0),
    Column("status", String(16), default="active"),    # active / broken
    Column("bound_at", DateTime, default=datetime.now),
    Column("broken_at", DateTime),
    UniqueConstraint("user1_id", "user2_id", "rel_type", name="uq_relationship_pair"),
)

# ---------- 商城与道具 ----------
shop_items = Table(
    "shop_items", metadata,
    Column("id", Integer, primary_key=True),
    Column("item_key", String(40), unique=True, nullable=False),
    Column("name", String(80), nullable=False),
    Column("icon", String(32)),
    Column("category", String(20), default="gift"),   # gift / title / avatar_frame / bubble / effect
    Column("price", Integer, default=0),
    Column("description", Text),
    Column("favorability_boost", Integer, default=0),  # 赠送时增加的好感度
    Column("unlock_favorability", Integer, default=0),  # 绑定关系后解锁所需好感度
    Column("available", Integer, default=1),
    Column("created_at", DateTime, default=datetime.now),
)

user_items = Table(
    "user_items", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("shop_item_id", Integer, nullable=False),
    Column("source", String(20), default="gift"),       # gift / purchase / bind / redeem
    Column("from_user_id", Integer),
    Column("quantity", Integer, default=1),
    Column("is_active", Integer, default=0),
    Column("expires_at", DateTime),
    Column("acquired_at", DateTime, default=datetime.now),
    UniqueConstraint("user_id", "shop_item_id", "from_user_id", name="uq_user_item"),
)

user_titles = Table(
    "user_titles", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer, nullable=False),
    Column("shop_item_id", Integer, nullable=False),
    Column("is_active", Integer, default=0),
    Column("expires_at", DateTime),
    Column("acquired_at", DateTime, default=datetime.now),
    UniqueConstraint("user_id", "shop_item_id", name="uq_user_title"),
)

RELATION_TYPES = {
    "couple":     {"name": "情侣", "favorability_required": 100, "icon": "💏", "color": "#ec4899"},
    "bestie":     {"name": "闺蜜", "favorability_required": 80,  "icon": "👯", "color": "#f472b6"},
    "bro":        {"name": "兄弟", "favorability_required": 80,  "icon": "🤝", "color": "#60a5fa"},
    "confidant":  {"name": "知己", "favorability_required": 60,  "icon": "🌸", "color": "#a78bfa"},
}

FAVORABILITY_BY_ACTION = {
    "send_gift":       lambda price, count: max(1, price // 2) * count,
    "chat_message":    1,     # 每条私聊消息
    "voice_room":      5,     # 同在一个语音房 30 分钟
    "enter_voice":     2,     # 进房互相关注
    "call":            10,    # 成功通话
    "match":           20,    # 互相匹配
}

AVATARS = [f"/api/avatars/{index}.svg" for index in range(8)]

# 扩展礼物：加入好感度加成与分类
GIFTS = {
    "heart":   {"name": "爱心",   "emoji": "💝", "price": 1,   "favorability": 1},
    "diamond": {"name": "钻石",   "emoji": "💎", "price": 5,   "favorability": 3},
    "box":     {"name": "礼盒",   "emoji": "🎁", "price": 10,  "favorability": 5},
    "rose":    {"name": "玫瑰",   "emoji": "🌹", "price": 15,  "favorability": 8},
    "bear":    {"name": "小熊",   "emoji": "🧸", "price": 30,  "favorability": 15},
    "rocket":  {"name": "火箭",   "emoji": "🚀", "price": 66,  "favorability": 33},
    "crown":   {"name": "皇冠",   "emoji": "👑", "price": 88,  "favorability": 44},
    "trophy":  {"name": "奖杯",   "emoji": "🏆", "price": 100, "favorability": 50},
    "mic":     {"name": "话筒",   "emoji": "🎤", "price": 200, "favorability": 100},
    "rainbow": {"name": "彩虹",   "emoji": "🌈", "price": 520, "favorability": 260},
}

# 商城物品（礼物已在 GIFTS 中，商城额外提供称号和装扮）
SHOP_TITLES = [
    {"item_key": "title_lone_wolf",   "name": "独行者",     "icon": "🐺",  "category": "title", "price": 300,  "favorability_boost": 0, "description": "高冷独立的灵魂"},
    {"item_key": "title_crown_prince","name": "王冠殿下",   "icon": "👑",  "category": "title", "price": 888,  "favorability_boost": 0, "description": "天生的王者气息"},
    {"item_key": "title_sweetheart",  "name": "甜心宝贝",   "icon": "🍬",  "category": "title", "price": 520,  "favorability_boost": 0, "description": "甜蜜可爱的代名词"},
    {"item_key": "title_gamer_king",  "name": "电竞之王",   "icon": "🎮",  "category": "title", "price": 666,  "favorability_boost": 0, "description": "游戏世界的霸主"},
    {"item_key": "title_heart_throb", "name": "心动男神",   "icon": "💘",  "category": "title", "price": 999,  "favorability_boost": 0, "description": "让无数人怦然心动"},
    {"item_key": "title_confidant",   "name": "灵魂知己",   "icon": "🌸",  "category": "title", "price": 0,    "favorability_boost": 0, "unlock_favorability": 60, "description": "与好友达到知己等级自动解锁"},
    {"item_key": "title_bro",         "name": "铁杆兄弟",   "icon": "🤝",  "category": "title", "price": 0,    "favorability_boost": 0, "unlock_favorability": 80, "description": "与好友达到兄弟等级自动解锁"},
    {"item_key": "title_couple",      "name": "挚爱恋人",   "icon": "💏",  "category": "title", "price": 0,    "favorability_boost": 0, "unlock_favorability": 100, "description": "与伴侣建立情侣关系自动解锁"},
]

SHOP_FRAMES = [
    {"item_key": "frame_gold",    "name": "黄金边框",   "icon": "🟡",  "category": "avatar_frame", "price": 120, "favorability_boost": 0, "description": "闪耀的金色头像框"},
    {"item_key": "frame_rose",    "name": "玫瑰边框",   "icon": "🌹",  "category": "avatar_frame", "price": 180, "favorability_boost": 0, "description": "浪漫的玫瑰花框"},
    {"item_key": "frame_neon",    "name": "霓虹边框",   "icon": "💜",  "category": "avatar_frame", "price": 260, "favorability_boost": 0, "description": "赛博朋克风格"},
]

SHOP_EFFECTS = [
    {"item_key": "effect_party",  "name": "派对光环",   "icon": "🎉",  "category": "effect", "price": 200, "favorability_boost": 0, "description": "进房时的派对特效"},
    {"item_key": "effect_heart",  "name": "爱心雨",     "icon": "💖",  "category": "effect", "price": 380, "favorability_boost": 0, "description": "送礼时的爱心雨动效"},
]
TAG_SETS = [
    ["🎬 追剧", "🍰 美食", "🐱 养猫", "🎤 唱歌"],
    ["🎸 吉他", "🏔️ 登山", "📖 阅读"],
    ["📷 摄影", "🎨 设计", "☕ 咖啡"],
    ["🎮 游戏", "🎯 电竞", "🍜 美食"],
]


def clean_dict(mapping):
    result = {}
    for key, value in dict(mapping).items():
        if isinstance(value, datetime):
            value = value.strftime("%Y-%m-%d %H:%M:%S")
        result[key] = value
    return result


def fetch_one(conn, statement):
    row = conn.execute(statement).mappings().first()
    return clean_dict(row) if row else None


def fetch_all(conn, statement):
    return [clean_dict(row) for row in conn.execute(statement).mappings().all()]


def inserted_id(result):
    return result.inserted_primary_key[0]


def json_ok(data=None):
    return {"success": True, "data": data, "error": None}


def json_error(message, status_code=400):
    return JSONResponse({"success": False, "data": None, "error": message}, status_code=status_code)


def require_user(user):
    if not user:
        raise HTTPException(status_code=401, detail="请先登录")
    return user


def hash_token(user_id):
    expire = int(time.time()) + TOKEN_EXPIRE_HOURS * 3600
    signature = hmac.new(TOKEN_SECRET.encode(), f"{user_id}.{expire}".encode(), hashlib.sha256).hexdigest()[:32]
    return f"{user_id}.{expire}.{signature}"


def verify_token(token):
    try:
        user_id, expire, signature = token.split(".")
        if int(expire) < time.time():
            return None
        expected = hmac.new(TOKEN_SECRET.encode(), f"{user_id}.{expire}".encode(), hashlib.sha256).hexdigest()[:32]
        return int(user_id) if hmac.compare_digest(expected, signature) else None
    except (ValueError, TypeError, AttributeError):
        return None


async def get_current_user(authorization: str = Header(default="")):
    if not authorization.startswith("Bearer "):
        return None
    user_id = verify_token(authorization[7:])
    if user_id is None:
        return None
    with engine.connect() as conn:
        return fetch_one(conn, select(users).where(users.c.id == user_id))


def public_user(row, private=False):
    if not row:
        return None
    data = clean_dict(row)
    if not private:
        data.pop("phone", None)
    data["is_vip"] = bool(data.get("is_vip"))
    data["online"] = manager.is_online(data["id"]) if "manager" in globals() else False
    return data


def get_user_required(conn, user_id):
    row = fetch_one(conn, select(users).where(users.c.id == user_id))
    if not row:
        raise HTTPException(status_code=404, detail="用户不存在")
    return row


def get_conversation_id(conn, first, second):
    low, high = sorted((first, second))
    row = fetch_one(conn, select(chat_conversations).where(
        chat_conversations.c.user1_id == low,
        chat_conversations.c.user2_id == high,
    ))
    if row:
        return row["id"]
    result = conn.execute(insert(chat_conversations).values(user1_id=low, user2_id=high))
    return inserted_id(result)


def distance_km(first, second):
    if not all(first.get(k) is not None for k in ("lat", "lng")) or not all(second.get(k) is not None for k in ("lat", "lng")):
        return 0.0
    lat1, lng1, lat2, lng2 = map(math.radians, [first["lat"], first["lng"], second["lat"], second["lng"]])
    value = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lng2 - lng1) / 2) ** 2
    return round(6371 * 2 * math.asin(math.sqrt(value)), 1)


def create_notification(conn, user_id, from_user_id, kind, content):
    if user_id == from_user_id and kind != "system":
        return None
    result = conn.execute(insert(notifications).values(
        user_id=user_id, from_user_id=from_user_id, type=kind, content=content,
    ))
    return inserted_id(result)


async def push_notification(user_id, notification_id):
    if not notification_id:
        return
    with engine.connect() as conn:
        item = fetch_one(conn, select(notifications).where(notifications.c.id == notification_id))
    if item:
        await manager.send_user(user_id, "notification", item)


def adjust_favorability(conn, from_id, to_id, delta, gift=True):
    """增加 from_id → to_id 的好感度；同时增加反向（互有好感）。返回新增后 from->to 的值。"""
    if from_id == to_id or delta <= 0:
        return 0

    upsert_fav(conn, from_id, to_id, delta, gift)
    upsert_fav(conn, to_id, from_id, delta, False)  # 对方给送礼方也加好感（单向更多）

    row = conn.execute(
        select(user_favorites.c.value).where(
            user_favorites.c.from_user_id == from_id, user_favorites.c.to_user_id == to_id
        )
    ).scalar()
    return row or 0


def upsert_fav(conn, from_id, to_id, delta, is_gift_action):
    existing = conn.execute(
        select(user_favorites).where(
            user_favorites.c.from_user_id == from_id, user_favorites.c.to_user_id == to_id
        )
    ).mappings().first()
    if existing:
        values = {"value": user_favorites.c.value + delta, "updated_at": datetime.now()}
        if is_gift_action:
            values["gifts_sent"] = user_favorites.c.gifts_sent + 1
        conn.execute(
            update(user_favorites).where(
                user_favorites.c.from_user_id == from_id, user_favorites.c.to_user_id == to_id
            ).values(**values)
        )
    else:
        conn.execute(insert(user_favorites).values(
            from_user_id=from_id, to_user_id=to_id,
            value=delta, gifts_sent=1 if is_gift_action else 0,
            updated_at=datetime.now(), created_at=datetime.now(),
        ))


def update_relationship_on_favorability(conn, user1_id, user2_id):
    """检查是否满足绑定条件，自动创建/解除关系并解锁称号。"""
    low, high = sorted([user1_id, user2_id])

    favorite_high = conn.execute(
        select(user_favorites.c.value).where(
            user_favorites.c.from_user_id == high, user_favorites.c.to_user_id == low
        )
    ).scalar() or 0
    favorite_low = conn.execute(
        select(user_favorites.c.value).where(
            user_favorites.c.from_user_id == low, user_favorites.c.to_user_id == high
        )
    ).scalar() or 0
    mutual = favorite_high + favorite_low

    # 检查已有关系
    existing_rels = fetch_all(conn,
        select(user_relationships).where(
            or_(
                and_(user_relationships.c.user1_id == low, user_relationships.c.user2_id == high),
                and_(user_relationships.c.user1_id == high, user_relationships.c.user2_id == low),
            )
        )
    )

    new_rels = set()
    for rel_type, meta in RELATION_TYPES.items():
        if mutual >= meta["favorability_required"]:
            new_rels.add(rel_type)

    existing_map = {r["rel_type"]: r for r in existing_rels}

    for rel_type in new_rels:
        if rel_type not in existing_map or existing_map[rel_type]["status"] != "active":
            existing_row = conn.execute(
                select(user_relationships).where(
                    user_relationships.c.user1_id == low, user_relationships.c.user2_id == high,
                    user_relationships.c.rel_type == rel_type,
                )
            ).mappings().first()
            if existing_row:
                conn.execute(update(user_relationships).where(
                    user_relationships.c.id == existing_row["id"]
                ).values(
                    favorability=mutual, status="active",
                    bound_at=datetime.now(), broken_at=None,
                ))
            else:
                conn.execute(insert(user_relationships).values(
                    user1_id=low, user2_id=high, rel_type=rel_type,
                    favorability=mutual, status="active", bound_at=datetime.now(),
                ))
            # 解锁对应称号
            unlock_item_for_pair(conn, rel_type, low, high)

    for rel_type, row in existing_map.items():
        if rel_type not in new_rels and row["status"] == "active":
            conn.execute(update(user_relationships).where(
                user_relationships.c.id == row["id"]
            ).values(status="broken", broken_at=datetime.now(), favorability=mutual))

    return {"mutual": mutual, "active_relationships": list(new_rels)}


def unlock_item_for_pair(conn, rel_type, user1_id, user2_id):
    """建立关系时自动为双方解锁对应称号物品。"""
    key_map = {
        "confidant": "title_confidant",
        "bro":       "title_bro",
        "couple":    "title_couple",
        "bestie":    None,  # 闺蜜用固定名
    }
    item_key = key_map.get(rel_type)
    if rel_type == "bestie":
        item_key = "title_confidant"  # 闺蜜也用知己称号（可按需扩展）
    if not item_key:
        return

    item = fetch_one(conn, select(shop_items).where(shop_items.c.item_key == item_key))
    if not item:
        return

    for uid in (user1_id, user2_id):
        existing = conn.execute(
            select(user_items).where(user_items.c.user_id == uid, user_items.c.shop_item_id == item["id"])
        ).mappings().first()
        if not existing:
            conn.execute(insert(user_items).values(
                user_id=uid, shop_item_id=item["id"], source="bind",
                from_user_id=None, quantity=1, is_active=1,
            ))


class ConnectionManager:
    def __init__(self):
        self.user_sockets = {}
        self.socket_users = {}
        self.room_sockets = {}
        self.socket_rooms = {}
        self.room_mic = {}

    async def connect(self, websocket, user_id):
        await websocket.accept()
        self.user_sockets.setdefault(user_id, set()).add(websocket)
        self.socket_users[websocket] = user_id

    async def disconnect(self, websocket):
        user_id = self.socket_users.pop(websocket, None)
        if user_id in self.user_sockets:
            self.user_sockets[user_id].discard(websocket)
            if not self.user_sockets[user_id]:
                self.user_sockets.pop(user_id, None)
        rooms = self.socket_rooms.pop(websocket, set())
        for room_id in rooms:
            self.leave_room(websocket, room_id, user_id)
            await broadcast_room_state(room_id)
        if user_id:
            await self.broadcast_all("presence", {"user_id": user_id, "online": self.is_online(user_id)})

    def is_online(self, user_id):
        return bool(self.user_sockets.get(user_id))

    def room_user_ids(self, room_id):
        return {self.socket_users[socket] for socket in self.room_sockets.get(room_id, set()) if socket in self.socket_users}

    def room_online(self, room_id):
        return len(self.room_user_ids(room_id))

    def user_in_room(self, room_id, user_id):
        return user_id in self.room_user_ids(room_id)

    def join_room(self, websocket, room_id):
        user_id = self.socket_users[websocket]
        was_present = self.user_in_room(room_id, user_id)
        self.room_sockets.setdefault(room_id, set()).add(websocket)
        self.socket_rooms.setdefault(websocket, set()).add(room_id)
        if not was_present:
            self.room_mic.setdefault(room_id, {})[user_id] = False

    def leave_room(self, websocket, room_id, user_id=None):
        user_id = self.socket_users.get(websocket) if user_id is None else user_id
        self.room_sockets.get(room_id, set()).discard(websocket)
        self.socket_rooms.get(websocket, set()).discard(room_id)
        if user_id is not None and not self.user_in_room(room_id, user_id):
            self.room_mic.get(room_id, {}).pop(user_id, None)

    def set_room_mic(self, room_id, user_id, enabled):
        self.room_mic.setdefault(room_id, {})[user_id] = bool(enabled)

    async def send_socket(self, websocket, event_type, data):
        try:
            await websocket.send_json({"type": event_type, "data": data})
        except (RuntimeError, WebSocketDisconnect):
            pass

    async def send_user(self, user_id, event_type, data):
        for websocket in list(self.user_sockets.get(user_id, set())):
            await self.send_socket(websocket, event_type, data)

    async def send_room_user(self, room_id, user_id, event_type, data):
        for websocket in list(self.room_sockets.get(room_id, set())):
            if self.socket_users.get(websocket) == user_id:
                await self.send_socket(websocket, event_type, data)

    async def broadcast_room(self, room_id, event_type, data):
        for websocket in list(self.room_sockets.get(room_id, set())):
            await self.send_socket(websocket, event_type, data)

    async def broadcast_all(self, event_type, data):
        for websocket in list(self.socket_users):
            await self.send_socket(websocket, event_type, data)


manager = ConnectionManager()


async def broadcast_room_state(room_id):
    user_ids = manager.room_user_ids(room_id)
    rows = []
    if user_ids:
        with engine.connect() as conn:
            rows = fetch_all(conn, select(users).where(users.c.id.in_(user_ids)))
    mic_states = manager.room_mic.get(room_id, {})
    roster = [{
        "id": row["id"], "nickname": row["nickname"], "avatar": row["avatar"],
        "is_vip": bool(row["is_vip"]), "mic": bool(mic_states.get(row["id"])),
    } for row in sorted(rows, key=lambda item: item["id"])]
    online = len(roster)
    await manager.broadcast_room(room_id, "room.presence", {"room_id": room_id, "online": online})
    await manager.broadcast_room(room_id, "room.roster", {"room_id": room_id, "online": online, "users": roster})


def init_database():
    metadata.create_all(engine)
    with engine.begin() as conn:
        if conn.execute(select(func.count(users.c.id))).scalar() == 0:
            seed_users = [
                ("13800000001", "电竞老王", AVATARS[0], "晚上一起LOL开黑！", "male", 24, "上海", 31.23, 121.47, 0, 128),
                ("13800000002", "奶糖不加冰", AVATARS[1], "🍬 甜度满分的甜妹一枚", "female", 22, "北京", 39.90, 116.40, 1, 680),
                ("13800000003", "独立音乐人阿树", AVATARS[2], "🎸 用音乐讲故事", "male", 26, "成都", 30.57, 104.07, 0, 256),
                ("13800000004", "小鹿乱撞", AVATARS[3], "咖啡控 · 摄影爱好者", "female", 23, "上海", 31.25, 121.48, 0, 96),
                ("13800000005", "南城以北", AVATARS[4], "登山徒步 · 热爱生活", "male", 28, "深圳", 22.54, 114.06, 1, 320),
                ("13800000006", "画画的阿猫", AVATARS[5], "🎨 自由插画师", "female", 25, "杭州", 30.27, 120.15, 0, 188),
                ("13800000007", "糖糖酱", AVATARS[6], "可盐可甜", "female", 21, "北京", 39.92, 116.42, 0, 64),
                ("13800000008", "清风明月", AVATARS[7], "极简主义", "male", 27, "成都", 30.60, 104.10, 0, 48),
                ("13800000000", "我（你）", AVATARS[0], "👋 欢迎来到圈圈语音社！", "secret", 25, "上海", 31.23, 121.47, 1, 999),
            ]
            conn.execute(insert(users), [dict(zip(
                ("phone", "nickname", "avatar", "bio", "gender", "age", "location", "lat", "lng", "is_vip", "coins"), row,
            )) for row in seed_users])

        user_rows = fetch_all(conn, select(users))
        for row in user_rows:
            if not row.get("avatar") or row["avatar"].startswith("https://trae-api-cn.mchost.guru/"):
                row["avatar"] = AVATARS[(row["id"] - 1) % len(AVATARS)]
                conn.execute(update(users).where(users.c.id == row["id"]).values(avatar=row["avatar"]))
        user_ids = {row["phone"]: row["id"] for row in user_rows}
        if not user_ids:
            return

        if conn.execute(select(func.count(circles.c.id))).scalar() == 0:
            conn.execute(insert(circles), [
                {"name": "LOL英雄联盟圈", "icon": "🎮", "members": 128430},
                {"name": "独立音乐分享圈", "icon": "🎵", "members": 86543},
                {"name": "二次元同好圈", "icon": "🌸", "members": 253210},
                {"name": "单身交友圈", "icon": "💕", "members": 189432},
                {"name": "摄影交流圈", "icon": "📷", "members": 56789},
                {"name": "旅行攻略圈", "icon": "✈️", "members": 78123},
            ])
        circle_rows = fetch_all(conn, select(circles))
        circle_ids = {row["name"]: row["id"] for row in circle_rows}

        if conn.execute(select(func.count(posts.c.id))).scalar() == 0:
            seed_posts = [
                ("13800000001", "今晚LOL开黑，缺个辅助位！来个会玩的，赢了发红包 🎮💸", "上海", "LOL英雄联盟圈", 128, 46),
                ("13800000002", "有人今晚一起连麦看恐怖片吗？我带爆米花🍿 一个人看真的好怕 😭", "北京", "二次元同好圈", 342, 89),
                ("13800000003", "新写了一首歌《凌晨三点的风》，欢迎来我语音房听Demo，给点意见～🎧", "成都", "独立音乐分享圈", 1200, 234),
                ("13800000006", "今天画了一张新插画，欢迎来看看！", "杭州", "摄影交流圈", 567, 89),
                ("13800000007", "周末一起去探店！有推荐的吗？", "北京", "单身交友圈", 89, 23),
                ("13800000008", "周末徒步组队，有兴趣的私！", "成都", "旅行攻略圈", 12, 3),
            ]
            conn.execute(insert(posts), [{
                "user_id": user_ids[phone], "content": content, "location": location,
                "circle_id": circle_ids.get(circle), "likes": likes, "comments": comments,
                "created_at": datetime.now() - timedelta(minutes=index * 17 + 3),
            } for index, (phone, content, location, circle, likes, comments) in enumerate(seed_posts)])

        if conn.execute(select(func.count(voice_rooms.c.id))).scalar() == 0:
            seed_rooms = [
                ("13800000001", "深夜情感电台 · 聊心事 💔", "情感", 1234),
                ("13800000001", "LOL五黑 · 缺一个打野 🎮", "游戏", 876),
                ("13800000003", "唱歌交友 · 点歌就唱 🎤", "音乐", 542),
                ("13800000006", "读书会 · 今晚读《百年孤独》📖", "读书", 328),
                ("13800000002", "ASMR助眠 · 温柔耳语 🌙", "深夜电台", 189),
                ("13800000005", "探店分享 · 成都美食地图 🍜", "美食", 267),
            ]
            conn.execute(insert(voice_rooms), [{
                "host_id": user_ids[phone], "topic": topic, "category": category, "listeners": listeners,
                "started_at": datetime.now() - timedelta(hours=index + 1),
            } for index, (phone, topic, category, listeners) in enumerate(seed_rooms)])

        demo_id = user_ids.get("13800000000")
        if not demo_id:
            return
        if conn.execute(select(func.count(matches.c.id))).scalar() == 0:
            reverse_likes = [user_ids[p] for p in ("13800000002", "13800000008") if p in user_ids]
            for target_id in reverse_likes:
                conn.execute(insert(matches).values(user_id=target_id, target_id=demo_id, action="like"))
            peer_id = user_ids.get("13800000007")
            if peer_id:
                conn.execute(insert(matches).values(user_id=demo_id, target_id=peer_id, action="like", matched=1))
                conn.execute(insert(matches).values(user_id=peer_id, target_id=demo_id, action="like", matched=1))

        if conn.execute(select(func.count(chat_conversations.c.id))).scalar() == 0:
            demo_messages = {
                "13800000007": ["嘿！你也喜欢看恐怖片吗 😱", "今晚可以一起连麦看呀！"],
                "13800000008": ["周末徒步还缺人吗？", "装备已经准备好了。"],
                "13800000006": ["你的插画真好看！", "谢谢，欢迎来圈子交流。"],
            }
            for phone, contents in demo_messages.items():
                peer_id = user_ids.get(phone)
                if not peer_id:
                    continue
                conversation_id = get_conversation_id(conn, demo_id, peer_id)
                for index, content in enumerate(contents):
                    conn.execute(insert(chat_messages).values(
                        conversation_id=conversation_id,
                        sender_id=peer_id if index % 2 == 0 else demo_id,
                        content=content,
                        created_at=datetime.now() - timedelta(minutes=20 - index * 4),
                        read=0 if index % 2 == 0 else 1,
                    ))

        if conn.execute(select(func.count(notifications.c.id))).scalar() == 0:
            conn.execute(insert(notifications).values(
                user_id=demo_id, from_user_id=None, type="system", content="欢迎来到圈圈语音社，完成每日任务可以获得钻石。",
            ))

        if conn.execute(select(func.count(room_messages.c.id))).scalar() == 0:
            first_room = fetch_one(conn, select(voice_rooms).order_by(voice_rooms.c.id).limit(1))
            peer_id = user_ids.get("13800000004")
            if first_room and peer_id:
                conn.execute(insert(room_messages).values(
                    room_id=first_room["id"], user_id=peer_id, content="大家好，欢迎来到语音房！",
                ))

        # 商城种子数据：一次性写入全部配置好的称号、边框、特效
        if conn.execute(select(func.count(shop_items.c.id))).scalar() == 0:
            all_shop = []
            for gift_key, gift in GIFTS.items():
                all_shop.append({
                    "item_key": f"gift_{gift_key}", "name": gift["name"], "icon": gift["emoji"],
                    "category": "gift", "price": gift["price"],
                    "favorability_boost": gift["favorability"], "description": f"送出「{gift['name']}」可增加双方好感度",
                })
            for title in SHOP_TITLES:
                all_shop.append(title)
            for frame in SHOP_FRAMES:
                all_shop.append(frame)
            for effect in SHOP_EFFECTS:
                all_shop.append(effect)
            conn.execute(insert(shop_items), all_shop)


init_database()

app = FastAPI(title="圈圈语音社 API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
)


@app.exception_handler(HTTPException)
async def http_exception_handler(_, exc):
    return json_error(str(exc.detail), exc.status_code)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_, exc):
    return json_error("请求参数不完整或格式不正确", 422)


class LoginReq(BaseModel):
    phone: str = Field(min_length=5, max_length=32)
    nickname: Optional[str] = Field(default=None, max_length=80)
    code: Optional[str] = Field(default=None, max_length=8)
    captcha: Optional[str] = Field(default=None, max_length=8)


class OauthLoginReq(BaseModel):
    provider: str  # wechat / qq / apple
    openid: str = Field(min_length=6, max_length=128)
    nickname: Optional[str] = Field(default=None, max_length=80)
    avatar: Optional[str] = Field(default=None, max_length=255)
    gender: Optional[str] = None


class ProfileReq(BaseModel):
    nickname: Optional[str] = Field(default=None, min_length=1, max_length=80)
    bio: Optional[str] = Field(default=None, max_length=500)
    gender: Optional[str] = None
    age: Optional[int] = Field(default=None, ge=18, le=100)
    location: Optional[str] = Field(default=None, max_length=80)
    lat: Optional[float] = None
    lng: Optional[float] = None
    avatar: Optional[str] = None


class PostReq(BaseModel):
    content: str = Field(min_length=1, max_length=500)
    image: Optional[str] = None
    location: Optional[str] = None
    circle_id: Optional[int] = None


class CommentReq(BaseModel):
    content: str = Field(min_length=1, max_length=300)


class MatchReq(BaseModel):
    target_id: int
    action: str


class ChatSendReq(BaseModel):
    target_id: int
    content: str = Field(min_length=1, max_length=2_000_000)
    msg_type: str = "text"


class VipPayReq(BaseModel):
    plan: str
    pay_method: str = "wechat"


class RechargeReq(BaseModel):
    coins: int
    pay_method: str = "wechat"


class RoomReq(BaseModel):
    topic: str = Field(min_length=2, max_length=200)
    category: str = Field(default="情感", max_length=60)


class RoomMessageReq(BaseModel):
    content: str = Field(min_length=1, max_length=500)


class GiftReq(BaseModel):
    gift_key: str
    count: int = Field(default=1, ge=1, le=99)


class CircleReq(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    icon: str = Field(default="💬", max_length=32)


class ShopPurchaseReq(BaseModel):
    item_key: str


class RelationshipReq(BaseModel):
    target_id: int
    rel_type: str


class TitleActivateReq(BaseModel):
    item_key: str


@app.get("/api/health")
async def health():
    return json_ok({
        "status": "ok", "time": datetime.now().isoformat(), "database": engine.dialect.name,
        "online_users": len(manager.user_sockets),
    })


@app.get("/api/avatars/{avatar_id}.svg")
async def avatar_illustration(avatar_id: int):
    palettes = [
        ("#312e81", "#a855f7", "#f4c7a1", "#20243a"),
        ("#831843", "#ec4899", "#f6c9a8", "#672143"),
        ("#0c4a6e", "#38bdf8", "#eec29e", "#172554"),
        ("#065f46", "#34d399", "#f3c5a5", "#7c2d12"),
        ("#7c2d12", "#fb923c", "#dcb18e", "#1f2937"),
        ("#4c1d95", "#c084fc", "#f0c6a7", "#3f2d20"),
        ("#9f1239", "#fb7185", "#f7cfb3", "#501724"),
        ("#164e63", "#22d3ee", "#e5b995", "#111827"),
    ]
    background, accent, skin, hair = palettes[avatar_id % len(palettes)]
    variant = avatar_id % 4
    fringe = [
        '<path d="M28 50Q31 18 64 18t36 32Q82 33 65 37 45 26 28 50" fill="%s"/>' % hair,
        '<path d="M27 52Q24 16 64 16t38 36Q83 30 65 29 47 48 27 52" fill="%s"/>' % hair,
        '<path d="M26 50Q29 17 63 17t39 33Q79 27 59 38 45 28 26 50" fill="%s"/>' % hair,
        '<path d="M28 48Q32 18 64 18t36 30Q84 35 72 31 54 45 28 48" fill="%s"/>' % hair,
    ][variant]
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" role="img" aria-label="圈圈用户头像">
<defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="{background}"/><stop offset="1" stop-color="{accent}"/></linearGradient></defs>
<rect width="128" height="128" rx="24" fill="url(#bg)"/><circle cx="103" cy="22" r="18" fill="#fff" opacity=".1"/><circle cx="19" cy="108" r="27" fill="#fff" opacity=".08"/>
<path d="M22 128q3-38 42-38t42 38" fill="{accent}"/><path d="M52 78h24v20H52z" fill="{skin}"/>
<ellipse cx="64" cy="53" rx="35" ry="39" fill="{skin}"/>{fringe}
<ellipse cx="51" cy="55" rx="3" ry="4" fill="#27243a"/><ellipse cx="77" cy="55" rx="3" ry="4" fill="#27243a"/>
<path d="M55 70q9 8 18 0" fill="none" stroke="#a85555" stroke-width="3" stroke-linecap="round"/>
<path d="M38 88q26 20 52 0l9 40H29z" fill="{accent}"/><path d="M53 91l11 10 11-10" fill="none" stroke="#fff" stroke-width="3" opacity=".7"/>
</svg>'''
    return Response(content=svg, media_type="image/svg+xml", headers={"Cache-Control": "public, max-age=86400"})


@app.post("/api/auth/send-code")
async def send_code(req: dict):
    """发送验证码。本地实现：生成 6 位验证码存入内存，直接返回（模拟已发送）。"""
    phone = str(req.get("phone") or "").strip()
    if not phone or len(phone) < 6:
        return json_error("手机号格式不正确")
    code = f"{random.randint(0, 999999):06d}"
    phone_codes[phone] = code  # 内存存储，5 分钟有效
    # 本地开发版：直接把验证码返回给前端（生产版应通过短信通道下发，不应返回）
    return json_ok({"expire": 300, "dev_code": code, "hint": "本地开发模式，验证码已在 response.data.dev_code 返回；生产版将通过短信下发"})


@app.post("/api/auth/login")
async def login(req: LoginReq):
    phone = req.phone.strip()
    # 验证码校验（本地测试版如果没有 code/captcha 也放行，方便调试）
    supplied = req.code or req.captcha
    if supplied:
        expected = phone_codes.get(phone)
        if not expected:
            return json_error("请先获取验证码")
        if supplied != expected:
            return json_error("验证码错误")
        phone_codes.pop(phone, None)

    with engine.begin() as conn:
        user = fetch_one(conn, select(users).where(users.c.phone == phone))
        if not user:
            nickname = (req.nickname or f"用户{phone[-4:]}").strip()
            result = conn.execute(insert(users).values(
                phone=phone, nickname=nickname, avatar=AVATARS[len(phone) % len(AVATARS)],
                bio="这个人很神秘，还没有填写简介。", coins=128,
            ))
            user = fetch_one(conn, select(users).where(users.c.id == inserted_id(result)))
    return json_ok({"token": hash_token(user["id"]), "token_type": "Bearer", "user": public_user(user, True)})


@app.post("/api/auth/oauth")
async def oauth_login(req: OauthLoginReq):
    """第三方登录（模拟实现：openid 存到 users.oauth_openid）。"""
    if req.provider not in ("wechat", "qq", "apple"):
        return json_error("不支持的第三方平台")
    oauth_col = f"oauth_{req.provider}_openid"
    with engine.begin() as conn:
        # 确保列存在
        try:
            result = conn.execute(select(users).where(text(f"{oauth_col} = :oid")).bindparams(oid=req.openid)).mappings().first()
        except Exception:
            # 列不存在，动态添加
            try:
                conn.execute(text(f"ALTER TABLE users ADD COLUMN {oauth_col} VARCHAR(128)"))
                conn.commit()
                result = conn.execute(select(users).where(text(f"{oauth_col} = :oid")).bindparams(oid=req.openid)).mappings().first()
            except Exception:
                result = None
        if result:
            user = dict(result)
        else:
            new_phone = f"{req.provider[:2]}{hash(req.openid) % 10**10:010d}"
            nickname = req.nickname or f"{req.provider}用户"
            avatar = req.avatar or AVATARS[abs(hash(req.openid)) % len(AVATARS)]
            gender = req.gender if req.gender in ("male", "female", "secret") else "secret"
            conn.execute(text(
                f"INSERT INTO users (phone, nickname, avatar, bio, gender, coins, {oauth_col}) "
                f"VALUES (:ph, :nk, :av, '第三方登录用户', :gd, 128, :oid)"
            ).bindparams(ph=new_phone, nk=nickname, av=avatar, gd=gender, oid=req.openid))
            user = fetch_one(conn, select(users).where(users.c.phone == new_phone))
    return json_ok({"token": hash_token(user["id"]), "token_type": "Bearer", "user": public_user(user, True), "is_new": True})


@app.get("/api/auth/me")
async def me(user=Depends(get_current_user)):
    require_user(user)
    return json_ok(public_user(user, True))


@app.patch("/api/profile")
async def update_profile(req: ProfileReq, user=Depends(get_current_user)):
    require_user(user)
    values = req.model_dump(exclude_none=True)
    if not values:
        return json_ok(public_user(user, True))
    with engine.begin() as conn:
        conn.execute(update(users).where(users.c.id == user["id"]).values(**values))
        updated = fetch_one(conn, select(users).where(users.c.id == user["id"]))
    return json_ok(public_user(updated, True))


@app.get("/api/profile")
async def profile(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        user_posts = fetch_all(conn, select(posts).where(posts.c.user_id == user["id"]).order_by(desc(posts.c.created_at)).limit(20))
        post_count = conn.execute(select(func.count(posts.c.id)).where(posts.c.user_id == user["id"])).scalar()
        room_count = conn.execute(select(func.count(voice_rooms.c.id)).where(voice_rooms.c.host_id == user["id"])).scalar()
        gift_count = conn.execute(
            select(func.coalesce(func.sum(room_messages.c.gift_count), 0))
            .select_from(room_messages.join(voice_rooms, room_messages.c.room_id == voice_rooms.c.id))
            .where(voice_rooms.c.host_id == user["id"])
        ).scalar()
    data = public_user(user, True)
    data.update({"posts": user_posts, "post_count": post_count, "room_count": room_count, "gift_count": gift_count or 0})
    return json_ok(data)


@app.get("/api/users/nearby")
async def nearby_users(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(users).where(users.c.id != user["id"]).limit(100))
        following = {row["target_id"] for row in fetch_all(conn, select(follows).where(follows.c.user_id == user["id"]))}
    result = []
    for row in rows:
        item = public_user(row)
        item["distance_km"] = distance_km(user, row)
        item["following"] = row["id"] in following
        result.append(item)
    result.sort(key=lambda item: item["distance_km"])
    return json_ok(result[:20])


@app.get("/api/users/{user_id}")
async def get_user(user_id: int):
    with engine.connect() as conn:
        row = get_user_required(conn, user_id)
    return json_ok(public_user(row))


@app.post("/api/users/{user_id}/follow")
async def follow_user(user_id: int, user=Depends(get_current_user)):
    require_user(user)
    if user_id == user["id"]:
        return json_error("不能关注自己")
    notification_id = None
    with engine.begin() as conn:
        get_user_required(conn, user_id)
        existing = fetch_one(conn, select(follows).where(follows.c.user_id == user["id"], follows.c.target_id == user_id))
        if existing:
            conn.execute(delete(follows).where(follows.c.id == existing["id"]))
            conn.execute(update(users).where(users.c.id == user_id).values(followers_count=case((users.c.followers_count > 0, users.c.followers_count - 1), else_=0)))
            conn.execute(update(users).where(users.c.id == user["id"]).values(following_count=case((users.c.following_count > 0, users.c.following_count - 1), else_=0)))
            following = False
        else:
            conn.execute(insert(follows).values(user_id=user["id"], target_id=user_id))
            conn.execute(update(users).where(users.c.id == user_id).values(followers_count=users.c.followers_count + 1))
            conn.execute(update(users).where(users.c.id == user["id"]).values(following_count=users.c.following_count + 1))
            notification_id = create_notification(conn, user_id, user["id"], "follow", f"{user['nickname']} 关注了你")
            following = True
    await push_notification(user_id, notification_id)
    return json_ok({"following": following})


@app.get("/api/search")
async def global_search(q: str = Query(default="", max_length=100), user=Depends(get_current_user)):
    require_user(user)
    keyword = q.strip()
    if not keyword:
        return json_ok({"users": [], "posts": [], "circles": [], "rooms": []})
    pattern = f"%{keyword}%"
    with engine.connect() as conn:
        user_rows = fetch_all(conn, select(users).where(or_(users.c.nickname.like(pattern), users.c.bio.like(pattern))).limit(8))
        post_rows = fetch_all(conn, select(posts, users.c.nickname, users.c.avatar).join(users, posts.c.user_id == users.c.id).where(posts.c.content.like(pattern)).order_by(desc(posts.c.created_at)).limit(8))
        circle_rows = fetch_all(conn, select(circles).where(circles.c.name.like(pattern)).limit(8))
        room_rows = fetch_all(conn, select(voice_rooms).where(voice_rooms.c.topic.like(pattern), voice_rooms.c.status == "live").limit(8))
    return json_ok({
        "users": [public_user(row) for row in user_rows], "posts": post_rows,
        "circles": circle_rows, "rooms": room_rows,
    })


def feed_page(conn, page, size, current_user, circle_id=None, tab="recommend"):
    filters = []
    if circle_id is not None:
        filters.append(posts.c.circle_id == circle_id)
    if tab == "city" and current_user.get("location"):
        filters.append(posts.c.location == current_user["location"])
    if tab == "following":
        filters.append(posts.c.user_id.in_(select(follows.c.target_id).where(follows.c.user_id == current_user["id"])))
    where = and_(*filters) if filters else True
    total = conn.execute(select(func.count(posts.c.id)).where(where)).scalar()
    statement = select(posts, users.c.nickname, users.c.avatar).join(users, posts.c.user_id == users.c.id).where(where)
    statement = statement.order_by(desc(posts.c.created_at)).limit(size).offset((page - 1) * size)
    items = fetch_all(conn, statement)
    liked = {row["post_id"] for row in fetch_all(conn, select(post_likes).where(post_likes.c.user_id == current_user["id"]))}
    for item in items:
        item["liked"] = item["id"] in liked
        item["comments_list"] = fetch_all(conn, select(post_comments, users.c.nickname, users.c.avatar).join(users, post_comments.c.user_id == users.c.id).where(post_comments.c.post_id == item["id"]).order_by(desc(post_comments.c.id)).limit(3))
    return {"items": items, "total": total, "page": page, "size": size, "pages": math.ceil(total / size) if total else 0}


@app.get("/api/feed/discover")
async def discover(page: int = 1, size: int = 20, tab: str = "recommend", user=Depends(get_current_user)):
    require_user(user)
    page, size = max(page, 1), min(max(size, 1), 50)
    with engine.connect() as conn:
        result = feed_page(conn, page, size, user, tab=tab)
    return json_ok(result)


@app.post("/api/feed/post")
async def create_post(req: PostReq, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        result = conn.execute(insert(posts).values(
            user_id=user["id"], content=req.content.strip(), image=req.image,
            location=req.location or user.get("location"), circle_id=req.circle_id,
        ))
        post_id = inserted_id(result)
        item = fetch_one(conn, select(posts, users.c.nickname, users.c.avatar).join(users, posts.c.user_id == users.c.id).where(posts.c.id == post_id))
    item.update({"liked": False, "comments_list": []})
    await manager.broadcast_all("feed.new", item)
    return json_ok(item)


@app.post("/api/feed/post/{post_id}/like")
async def like_post(post_id: int, user=Depends(get_current_user)):
    require_user(user)
    notification_id = None
    with engine.begin() as conn:
        post = fetch_one(conn, select(posts).where(posts.c.id == post_id))
        if not post:
            raise HTTPException(status_code=404, detail="动态不存在")
        existing = fetch_one(conn, select(post_likes).where(post_likes.c.post_id == post_id, post_likes.c.user_id == user["id"]))
        if existing:
            conn.execute(delete(post_likes).where(post_likes.c.id == existing["id"]))
            conn.execute(update(posts).where(posts.c.id == post_id).values(likes=case((posts.c.likes > 0, posts.c.likes - 1), else_=0)))
            liked = False
        else:
            conn.execute(insert(post_likes).values(post_id=post_id, user_id=user["id"]))
            conn.execute(update(posts).where(posts.c.id == post_id).values(likes=posts.c.likes + 1))
            notification_id = create_notification(conn, post["user_id"], user["id"], "like", f"{user['nickname']} 给你的动态点了赞")
            liked = True
        likes = conn.execute(select(posts.c.likes).where(posts.c.id == post_id)).scalar()
    await push_notification(post["user_id"], notification_id)
    return json_ok({"liked": liked, "likes": likes})


@app.get("/api/feed/post/{post_id}/comments")
async def comments(post_id: int, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        items = fetch_all(conn, select(post_comments, users.c.nickname, users.c.avatar).join(users, post_comments.c.user_id == users.c.id).where(post_comments.c.post_id == post_id).order_by(post_comments.c.id))
    return json_ok(items)


@app.post("/api/feed/post/{post_id}/comments")
async def add_comment(post_id: int, req: CommentReq, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        post = fetch_one(conn, select(posts).where(posts.c.id == post_id))
        if not post:
            raise HTTPException(status_code=404, detail="动态不存在")
        result = conn.execute(insert(post_comments).values(post_id=post_id, user_id=user["id"], content=req.content.strip()))
        conn.execute(update(posts).where(posts.c.id == post_id).values(comments=posts.c.comments + 1))
        notification_id = create_notification(conn, post["user_id"], user["id"], "comment", f"{user['nickname']} 评论了你的动态：{req.content[:80]}")
        item = fetch_one(conn, select(post_comments, users.c.nickname, users.c.avatar).join(users, post_comments.c.user_id == users.c.id).where(post_comments.c.id == inserted_id(result)))
        count = conn.execute(select(posts.c.comments).where(posts.c.id == post_id)).scalar()
    await push_notification(post["user_id"], notification_id)
    return json_ok({"comment": item, "comments": count})


@app.get("/api/match/cards")
async def match_cards(gender: str = "", max_age: int = 100, max_distance: float = 20000, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(users).where(
            users.c.id != user["id"],
            ~users.c.id.in_(select(matches.c.target_id).where(matches.c.user_id == user["id"])),
        ))
    items = []
    for row in rows:
        if gender in ("male", "female") and row.get("gender") != gender:
            continue
        if row.get("age") and row["age"] > max_age:
            continue
        distance = distance_km(user, row)
        if distance > max_distance:
            continue
        item = public_user(row)
        item["distance_km"] = distance
        item["match_rate"] = 75 + ((user["id"] * 7 + row["id"] * 3) % 24)
        item["tags"] = TAG_SETS[row["id"] % len(TAG_SETS)]
        items.append(item)
    random.shuffle(items)
    return json_ok(items[:20])


@app.post("/api/match/action")
async def match_action(req: MatchReq, user=Depends(get_current_user)):
    require_user(user)
    if req.action not in ("like", "pass", "super"):
        return json_error("未知匹配操作")
    if req.target_id == user["id"]:
        return json_error("不能匹配自己")
    notification_ids = []
    with engine.begin() as conn:
        target = get_user_required(conn, req.target_id)
        existing = fetch_one(conn, select(matches).where(matches.c.user_id == user["id"], matches.c.target_id == req.target_id))
        is_like = req.action in ("like", "super")
        reverse = fetch_one(conn, select(matches).where(
            matches.c.user_id == req.target_id, matches.c.target_id == user["id"], matches.c.action.in_(["like", "super"]),
        )) if is_like else None
        matched = bool(reverse)
        values = {"action": req.action, "matched": int(matched), "created_at": datetime.now()}
        if existing:
            conn.execute(update(matches).where(matches.c.id == existing["id"]).values(**values))
        else:
            conn.execute(insert(matches).values(user_id=user["id"], target_id=req.target_id, **values))
        if matched:
            conn.execute(update(matches).where(matches.c.id == reverse["id"]).values(matched=1))
            get_conversation_id(conn, user["id"], req.target_id)
            notification_ids.append((req.target_id, create_notification(conn, req.target_id, user["id"], "match", f"你和 {user['nickname']} 互相喜欢了！")))
            notification_ids.append((user["id"], create_notification(conn, user["id"], req.target_id, "match", f"你和 {target['nickname']} 互相喜欢了！")))
        elif is_like:
            notification_ids.append((req.target_id, create_notification(conn, req.target_id, user["id"], "like", f"{user['nickname']} 喜欢了你")))
    for target_user_id, notification_id in notification_ids:
        await push_notification(target_user_id, notification_id)
    if matched:
        await manager.send_user(req.target_id, "match.success", {"user": public_user(user)})
    return json_ok({"matched": matched, "target": public_user(target)})


@app.delete("/api/match/action/{target_id}")
async def undo_match_action(target_id: int, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        conn.execute(delete(matches).where(matches.c.user_id == user["id"], matches.c.target_id == target_id))
    return json_ok({"undone": True})


@app.get("/api/match/list")
async def my_matches(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(matches, users.c.id.label("peer_id"), users.c.nickname, users.c.avatar).join(users, matches.c.target_id == users.c.id).where(
            matches.c.user_id == user["id"], matches.c.matched == 1,
        ).order_by(desc(matches.c.created_at)).limit(50))
    for row in rows:
        row["id"] = row["peer_id"]
    return json_ok(rows)


def room_payload(conn, row):
    host = fetch_one(conn, select(users).where(users.c.id == row["host_id"]))
    item = clean_dict(row)
    item["host_nickname"] = host["nickname"] if host else "未知主播"
    item["host_avatar"] = host["avatar"] if host else AVATARS[0]
    item["online"] = manager.room_online(row["id"])
    return item


@app.get("/api/voice/rooms")
async def voice_rooms_api(category: Optional[str] = None, followed: bool = False, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        statement = select(voice_rooms).where(voice_rooms.c.status == "live")
        if category:
            statement = statement.where(voice_rooms.c.category == category)
        if followed:
            statement = statement.where(voice_rooms.c.host_id.in_(select(follows.c.target_id).where(follows.c.user_id == user["id"])))
        rows = fetch_all(conn, statement.order_by(desc(voice_rooms.c.listeners)))
        return json_ok([room_payload(conn, row) for row in rows])


@app.post("/api/voice/rooms")
async def create_voice_room(req: RoomReq, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        result = conn.execute(insert(voice_rooms).values(host_id=user["id"], topic=req.topic.strip(), category=req.category.strip()))
        room = fetch_one(conn, select(voice_rooms).where(voice_rooms.c.id == inserted_id(result)))
        payload = room_payload(conn, room)
    await manager.broadcast_all("voice.new", payload)
    return json_ok(payload)


def record_room_visit(conn, room_id, user_id):
    today = datetime.now().strftime("%Y-%m-%d")
    existing = fetch_one(conn, select(room_visits).where(
        room_visits.c.room_id == room_id, room_visits.c.user_id == user_id, room_visits.c.visited_on == today,
    ))
    if not existing:
        conn.execute(insert(room_visits).values(room_id=room_id, user_id=user_id, visited_on=today))


@app.post("/api/voice/rooms/{room_id}/join")
async def join_voice_room(room_id: int, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        room = fetch_one(conn, select(voice_rooms).where(voice_rooms.c.id == room_id, voice_rooms.c.status == "live"))
        if not room:
            raise HTTPException(status_code=404, detail="语音房不存在或已关闭")
        record_room_visit(conn, room_id, user["id"])
    return json_ok({"joined": True, "room_id": room_id})


@app.get("/api/voice/rooms/{room_id}/messages")
async def voice_room_messages(room_id: int, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(room_messages, users.c.nickname, users.c.avatar).join(users, room_messages.c.user_id == users.c.id).where(room_messages.c.room_id == room_id).order_by(desc(room_messages.c.id)).limit(50))
    rows.reverse()
    return json_ok(rows)


@app.post("/api/voice/rooms/{room_id}/messages")
async def send_voice_room_message(room_id: int, req: RoomMessageReq, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        if not fetch_one(conn, select(voice_rooms).where(voice_rooms.c.id == room_id)):
            raise HTTPException(status_code=404, detail="语音房不存在")
        result = conn.execute(insert(room_messages).values(room_id=room_id, user_id=user["id"], content=req.content.strip()))
        item = fetch_one(conn, select(room_messages, users.c.nickname, users.c.avatar).join(users, room_messages.c.user_id == users.c.id).where(room_messages.c.id == inserted_id(result)))
    await manager.broadcast_room(room_id, "room.message", item)
    return json_ok(item)


@app.get("/api/gifts")
async def gift_list():
    return json_ok([{"key": key, **value} for key, value in GIFTS.items()])


@app.post("/api/voice/rooms/{room_id}/gift")
async def send_room_gift(room_id: int, req: GiftReq, user=Depends(get_current_user)):
    require_user(user)
    gift = GIFTS.get(req.gift_key)
    if not gift:
        return json_error("礼物不存在")
    total_price = gift["price"] * req.count
    with engine.begin() as conn:
        room = fetch_one(conn, select(voice_rooms).where(voice_rooms.c.id == room_id))
        if not room:
            raise HTTPException(status_code=404, detail="语音房不存在")
        result = conn.execute(update(users).where(users.c.id == user["id"], users.c.coins >= total_price).values(coins=users.c.coins - total_price))
        if result.rowcount == 0:
            return json_error("钻石余额不足，请先充值")
        message_result = conn.execute(insert(room_messages).values(
            room_id=room_id, user_id=user["id"], content=f"送出 {gift['name']} ×{req.count}", msg_type="gift",
            gift_key=req.gift_key, gift_name=gift["name"], gift_emoji=gift["emoji"],
            gift_count=req.count, gift_price=total_price,
        ))
        conn.execute(insert(wallet_transactions).values(
            user_id=user["id"], kind="gift", coins=-total_price, note=f"{gift['name']} ×{req.count}",
        ))
        # ========== 礼物收益分成：房主 30%，平台 70% ==========
        host_revenue = int(total_price * 0.3)
        platform_revenue = total_price - host_revenue  # 防止浮点误差
        if host_revenue > 0:
            conn.execute(update(users).where(users.c.id == room["host_id"]).values(
                coins=users.c.coins + host_revenue,
            ))
            conn.execute(insert(wallet_transactions).values(
                user_id=room["host_id"], kind="gift_revenue", coins=host_revenue,
                note=f"收到「{gift['name']}」收益（30%）来自 {user['nickname']}",
            ))
        PLATFORM_WALLET["coins"] += platform_revenue
        # ====================================================
        notification_id = create_notification(conn, room["host_id"], user["id"], "gift", f"{user['nickname']} 送出 {gift['name']} ×{req.count}（房主收益 +{host_revenue}💎）")
        item = fetch_one(conn, select(room_messages, users.c.nickname, users.c.avatar).join(users, room_messages.c.user_id == users.c.id).where(room_messages.c.id == inserted_id(message_result)))
        balance = conn.execute(select(users.c.coins).where(users.c.id == user["id"])).scalar()

        # 增加送礼方与房主之间的好感度
        fav_delta = gift["favorability"] * req.count
        new_fav = adjust_favorability(conn, user["id"], room["host_id"], fav_delta, gift=True)
        rel_info = update_relationship_on_favorability(conn, user["id"], room["host_id"])

    await manager.broadcast_room(room_id, "room.gift", item)
    await manager.send_user(user["id"], "wallet.update", {"coins": balance})
    await push_notification(room["host_id"], notification_id)

    # 如果触发了新关系 / 称号解锁，给双方发通知
    for rel_type in rel_info.get("active_relationships", []):
        if rel_type not in ("confidant", "bro", "couple", "bestie"):
            continue
        meta = RELATION_TYPES[rel_type]
        if not meta.get("icon"):
            continue
        await manager.send_user(user["id"], "relationship.bound", {
            "with_user_id": room["host_id"], "rel_type": rel_type,
            "mutual_favorability": rel_info["mutual"], "icon": meta["icon"], "name": meta["name"],
        })
        await manager.send_user(room["host_id"], "relationship.bound", {
            "with_user_id": user["id"], "rel_type": rel_type,
            "mutual_favorability": rel_info["mutual"], "icon": meta["icon"], "name": meta["name"],
        })

    return json_ok({"message": item, "coins": balance, "favorability": new_fav, "favorability_delta": fav_delta,
                    "mutual_favorability": rel_info["mutual"], "active_relationships": rel_info["active_relationships"]})


@app.post("/api/voice/rooms/{room_id}/action")
async def room_action(room_id: int, payload: dict, user=Depends(get_current_user)):
    require_user(user)
    action = str(payload.get("action", ""))[:30]
    if action not in ("mic", "hand", "invite"):
        return json_error("未知房间操作")
    data = {"room_id": room_id, "action": action, "user": public_user(user)}
    await manager.broadcast_room(room_id, "room.action", data)
    return json_ok(data)


@app.get("/api/circles")
async def circles_api(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(circles).order_by(desc(circles.c.members)))
        joined = {row["circle_id"] for row in fetch_all(conn, select(circle_members).where(circle_members.c.user_id == user["id"]))}
        for row in rows:
            row["joined"] = row["id"] in joined
            row["post_count"] = conn.execute(select(func.count(posts.c.id)).where(posts.c.circle_id == row["id"])).scalar()
    return json_ok(rows)


@app.post("/api/circles")
async def create_circle(req: CircleReq, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        result = conn.execute(insert(circles).values(name=req.name.strip(), icon=req.icon.strip(), members=1))
        circle_id = inserted_id(result)
        conn.execute(insert(circle_members).values(circle_id=circle_id, user_id=user["id"]))
        item = fetch_one(conn, select(circles).where(circles.c.id == circle_id))
    item.update({"joined": True, "post_count": 0})
    return json_ok(item)


@app.post("/api/circles/{circle_id}/join")
async def join_circle(circle_id: int, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        if not fetch_one(conn, select(circles).where(circles.c.id == circle_id)):
            raise HTTPException(status_code=404, detail="频道不存在")
        existing = fetch_one(conn, select(circle_members).where(circle_members.c.circle_id == circle_id, circle_members.c.user_id == user["id"]))
        if existing:
            conn.execute(delete(circle_members).where(circle_members.c.id == existing["id"]))
            conn.execute(update(circles).where(circles.c.id == circle_id).values(members=case((circles.c.members > 0, circles.c.members - 1), else_=0)))
            joined = False
        else:
            conn.execute(insert(circle_members).values(circle_id=circle_id, user_id=user["id"]))
            conn.execute(update(circles).where(circles.c.id == circle_id).values(members=circles.c.members + 1))
            joined = True
        members = conn.execute(select(circles.c.members).where(circles.c.id == circle_id)).scalar()
    return json_ok({"joined": joined, "members": members})


@app.get("/api/circles/{circle_id}/posts")
async def circle_posts_api(circle_id: int, page: int = 1, size: int = 20, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        result = feed_page(conn, max(page, 1), min(size, 50), user, circle_id=circle_id)
    return json_ok(result)


@app.get("/api/circles/{circle_id}/rank")
async def circle_rank(circle_id: int, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(users.c.id, users.c.nickname, func.count(posts.c.id).label("score")).join(posts, posts.c.user_id == users.c.id).where(posts.c.circle_id == circle_id).group_by(users.c.id, users.c.nickname).order_by(desc("score")).limit(10))
    return json_ok(rows)


@app.get("/api/blocks")
async def blocked_users(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(users.c.id, users.c.nickname, users.c.avatar, users.c.bio, users.c.location).join(
            user_blocks, user_blocks.c.blocked_id == users.c.id,
        ).where(user_blocks.c.user_id == user["id"]).order_by(desc(user_blocks.c.id)))
    return json_ok(rows)


@app.post("/api/blocks/{target_id}")
async def toggle_blocked_user(target_id: int, user=Depends(get_current_user)):
    require_user(user)
    if target_id == user["id"]:
        return json_error("不能屏蔽自己")
    with engine.begin() as conn:
        get_user_required(conn, target_id)
        existing = fetch_one(conn, select(user_blocks).where(
            user_blocks.c.user_id == user["id"], user_blocks.c.blocked_id == target_id,
        ))
        if existing:
            conn.execute(delete(user_blocks).where(user_blocks.c.id == existing["id"]))
        else:
            conn.execute(insert(user_blocks).values(user_id=user["id"], blocked_id=target_id))
    return json_ok({"blocked": not bool(existing), "target_id": target_id})


@app.get("/api/chat/conversations")
async def conversations(user=Depends(get_current_user)): 
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn, select(chat_conversations).where(or_(
            chat_conversations.c.user1_id == user["id"], chat_conversations.c.user2_id == user["id"],
        )))
        result = []
        for row in rows:
            peer_id = row["user2_id"] if row["user1_id"] == user["id"] else row["user1_id"]
            peer = fetch_one(conn, select(users).where(users.c.id == peer_id))
            if not peer:
                continue
            last = fetch_one(conn, select(chat_messages).where(chat_messages.c.conversation_id == row["id"]).order_by(desc(chat_messages.c.id)).limit(1))
            unread = conn.execute(select(func.count(chat_messages.c.id)).where(
                chat_messages.c.conversation_id == row["id"], chat_messages.c.read == 0, chat_messages.c.sender_id != user["id"],
            )).scalar()
            result.append({
                "id": row["id"], "peer_id": peer_id, "peer_name": peer["nickname"], "peer_avatar": peer["avatar"],
                "online": manager.is_online(peer_id), "last_msg": last["content"] if last else "开始新的聊天吧",
                "last_time": last["created_at"] if last else row["created_at"], "unread": unread,
            })
        result.sort(key=lambda item: item["last_time"] or "", reverse=True)
    return json_ok(result)


@app.get("/api/chat/messages/{peer_id}")
async def chat_history(peer_id: int, page: int = 1, size: int = 50, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        get_user_required(conn, peer_id)
        conversation_id = get_conversation_id(conn, user["id"], peer_id)
        conn.execute(update(chat_messages).where(
            chat_messages.c.conversation_id == conversation_id, chat_messages.c.sender_id != user["id"],
        ).values(read=1))
        rows = fetch_all(conn, select(chat_messages, users.c.nickname, users.c.avatar).join(users, chat_messages.c.sender_id == users.c.id).where(
            chat_messages.c.conversation_id == conversation_id,
        ).order_by(desc(chat_messages.c.id)).limit(min(size, 100)).offset((max(page, 1) - 1) * size))
        peer = fetch_one(conn, select(users).where(users.c.id == peer_id))
        blocked = fetch_one(conn, select(user_blocks).where(
            user_blocks.c.user_id == user["id"], user_blocks.c.blocked_id == peer_id,
        ))
        peer_data = public_user(peer)
        peer_data["blocked"] = bool(blocked)
    rows.reverse()
    await manager.send_user(peer_id, "chat.read", {"peer_id": user["id"], "conversation_id": conversation_id})
    return json_ok({"conversation_id": conversation_id, "items": rows, "peer": peer_data})


@app.post("/api/chat/send")
async def send_chat_message(req: ChatSendReq, user=Depends(get_current_user)):
    require_user(user)
    if req.msg_type not in {"text", "image", "voice"}:
        return json_error("不支持的消息类型")
    if req.msg_type == "text" and len(req.content.strip()) > 1000:
        return json_error("文字消息不能超过1000字")
    with engine.begin() as conn:
        get_user_required(conn, req.target_id)
        block = fetch_one(conn, select(user_blocks).where(or_(
            and_(user_blocks.c.user_id == user["id"], user_blocks.c.blocked_id == req.target_id),
            and_(user_blocks.c.user_id == req.target_id, user_blocks.c.blocked_id == user["id"]),
        )))
        if block:
            return json_error("当前屏蔽关系下不能发送消息，请先解除屏蔽")
        conversation_id = get_conversation_id(conn, user["id"], req.target_id)
        result = conn.execute(insert(chat_messages).values(
            conversation_id=conversation_id, sender_id=user["id"], content=req.content.strip(), msg_type=req.msg_type[:20],
        ))
        item = fetch_one(conn, select(chat_messages, users.c.nickname, users.c.avatar).join(users, chat_messages.c.sender_id == users.c.id).where(chat_messages.c.id == inserted_id(result)))

        # 发送私聊消息增加一点点好感度（每 10 条触发一次，避免刷屏涨好感）
        count_rows = conn.execute(
            select(func.count(chat_messages.c.id)).where(
                chat_messages.c.conversation_id == conversation_id,
                chat_messages.c.sender_id == user["id"],
            )
        ).scalar() or 0
        if count_rows % 10 == 0 and count_rows > 0:
            adjust_favorability(conn, user["id"], req.target_id, 1, gift=False)
            update_relationship_on_favorability(conn, user["id"], req.target_id)

    item["peer_id"] = req.target_id
    await manager.send_user(req.target_id, "chat.message", item)
    await manager.send_user(user["id"], "chat.message", item)
    return json_ok(item)


@app.get("/api/notifications")
async def notification_list(type_filter: Optional[str] = None, user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        statement = select(notifications).where(notifications.c.user_id == user["id"])
        if type_filter:
            statement = statement.where(notifications.c.type == type_filter)
        items = fetch_all(conn, statement.order_by(desc(notifications.c.id)).limit(100))
        for item in items:
            if item.get("from_user_id"):
                sender = fetch_one(conn, select(users).where(users.c.id == item["from_user_id"]))
                item["from_nickname"] = sender["nickname"] if sender else "用户"
                item["from_avatar"] = sender["avatar"] if sender else AVATARS[0]
    return json_ok(items)


@app.post("/api/notifications/read-all")
async def read_all_notifications(user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        conn.execute(update(notifications).where(notifications.c.user_id == user["id"]).values(is_read=1))
    return json_ok({"read": True})


@app.post("/api/vip/pay")
async def vip_pay(req: VipPayReq, user=Depends(get_current_user)):
    require_user(user)
    plans = {
        "month": {"days": 30, "amount": 18, "label": "月度会员"},
        "quarter": {"days": 90, "amount": 48, "label": "季度会员"},
        "year": {"days": 365, "amount": 168, "label": "年度会员"},
    }
    plan = plans.get(req.plan)
    if not plan:
        return json_error("未知套餐")
    with engine.begin() as conn:
        current = get_user_required(conn, user["id"])
        conn.execute(insert(orders).values(
            user_id=user["id"], plan=req.plan, pay_method=req.pay_method[:30], amount=plan["amount"], status="test_success",
        ))
        base = datetime.now()
        if current.get("vip_expire"):
            try:
                old_expire = datetime.fromisoformat(current["vip_expire"])
                if old_expire > base:
                    base = old_expire
            except ValueError:
                pass
        expire = base + timedelta(days=plan["days"])
        bonus = 1000 if req.plan == "year" else 0
        conn.execute(update(users).where(users.c.id == user["id"]).values(
            is_vip=1, vip_expire=expire.isoformat(), coins=users.c.coins + bonus,
        ))
        balance = conn.execute(select(users.c.coins).where(users.c.id == user["id"])).scalar()
    await manager.send_user(user["id"], "wallet.update", {"coins": balance})
    return json_ok({"msg": f"{plan['label']}测试开通成功", "plan": req.plan, "expire": expire.strftime("%Y-%m-%d %H:%M"), "coins": balance, "mode": "test"})


@app.get("/api/wallet")
async def wallet(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        current = get_user_required(conn, user["id"])
        order_rows = fetch_all(conn, select(orders).where(orders.c.user_id == user["id"]).order_by(desc(orders.c.id)).limit(20))
        transaction_rows = fetch_all(conn, select(wallet_transactions).where(wallet_transactions.c.user_id == user["id"]).order_by(desc(wallet_transactions.c.id)).limit(20))
    return json_ok({
        "coins": current["coins"], "is_vip": bool(current["is_vip"]), "vip_expire": current["vip_expire"],
        "orders": order_rows, "transactions": transaction_rows,
    })


@app.post("/api/wallet/recharge")
async def recharge(req: RechargeReq, user=Depends(get_current_user)):
    require_user(user)
    if req.coins not in (6, 30, 68, 128, 328, 648):
        return json_error("请选择有效的充值档位")
    with engine.begin() as conn:
        conn.execute(update(users).where(users.c.id == user["id"]).values(coins=users.c.coins + req.coins))
        conn.execute(insert(orders).values(
            user_id=user["id"], plan=f"coins_{req.coins}", pay_method=req.pay_method[:30], amount=req.coins, status="test_success",
        ))
        conn.execute(insert(wallet_transactions).values(
            user_id=user["id"], kind="recharge", amount=req.coins, coins=req.coins, note="本地测试充值",
        ))
        balance = conn.execute(select(users.c.coins).where(users.c.id == user["id"])).scalar()
    await manager.send_user(user["id"], "wallet.update", {"coins": balance})
    return json_ok({"coins": balance, "added": req.coins, "mode": "test"})


def task_data(conn, user_id):
    start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    today = start.strftime("%Y-%m-%d")
    claimed = {row["task_key"] for row in fetch_all(conn, select(task_claims).where(task_claims.c.user_id == user_id, task_claims.c.claim_date == today))}
    counts = {
        "login": 1,
        "post": conn.execute(select(func.count(posts.c.id)).where(posts.c.user_id == user_id, posts.c.created_at >= start)).scalar(),
        "voice": conn.execute(select(func.count(func.distinct(room_visits.c.room_id))).where(room_visits.c.user_id == user_id, room_visits.c.visited_on == today)).scalar(),
        "match": conn.execute(select(func.count(matches.c.id)).where(matches.c.user_id == user_id, matches.c.created_at >= start, matches.c.action.in_(["like", "super"]))).scalar(),
    }
    definitions = [
        ("login", "登录签到", "🎯", 1, 10),
        ("post", "发布 1 条动态", "📝", 1, 20),
        ("voice", "进入 3 个语音房", "🎤", 3, 30),
        ("match", "喜欢 5 个人", "💬", 5, 50),
    ]
    return [{
        "task_key": key, "task_text": text, "icon": icon, "current": min(counts[key], target),
        "target": target, "progress": f"{min(counts[key], target)}/{target}", "reward": reward,
        "completed": counts[key] >= target, "claimed": key in claimed,
    } for key, text, icon, target, reward in definitions]


@app.get("/api/tasks")
async def task_list(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        return json_ok(task_data(conn, user["id"]))


@app.post("/api/tasks/{key}/complete")
async def complete_task(key: str, user=Depends(get_current_user)):
    require_user(user)
    with engine.begin() as conn:
        current_task = next((item for item in task_data(conn, user["id"]) if item["task_key"] == key), None)
        if not current_task:
            return json_error("任务不存在")
        if current_task["claimed"]:
            return json_error("今日奖励已领取")
        if not current_task["completed"]:
            return json_error(f"任务尚未完成，当前进度 {current_task['progress']}")
        reward = current_task["reward"]
        conn.execute(insert(task_claims).values(
            user_id=user["id"], task_key=key, claim_date=datetime.now().strftime("%Y-%m-%d"), reward=reward,
        ))
        conn.execute(update(users).where(users.c.id == user["id"]).values(coins=users.c.coins + reward))
        conn.execute(insert(wallet_transactions).values(user_id=user["id"], kind="task", coins=reward, note=current_task["task_text"]))
        balance = conn.execute(select(users.c.coins).where(users.c.id == user["id"])).scalar()
    await manager.send_user(user["id"], "wallet.update", {"coins": balance})
    return json_ok({"msg": f"任务奖励已领取：+{reward} 钻石", "reward": reward, "coins": balance})


@app.get("/api/stats")
async def site_stats(user=Depends(get_current_user)):
    require_user(user)
    with engine.connect() as conn:
        room_count = conn.execute(select(func.count(voice_rooms.c.id)).where(voice_rooms.c.status == "live")).scalar()
        nearby_count = conn.execute(select(func.count(users.c.id)).where(users.c.location == user.get("location"), users.c.id != user["id"])).scalar()
    return json_ok({"online": len(manager.user_sockets), "rooms": room_count, "nearby": nearby_count})


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    user_id = verify_token(websocket.query_params.get("token", ""))
    if user_id is None:
        await websocket.close(code=4401)
        return
    with engine.connect() as conn:
        user = fetch_one(conn, select(users).where(users.c.id == user_id))
    if not user:
        await websocket.close(code=4401)
        return
    await manager.connect(websocket, user_id)
    await manager.send_socket(websocket, "ready", {"user": public_user(user, True), "time": datetime.now().isoformat()})
    await manager.broadcast_all("presence", {"user_id": user_id, "online": True})
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                message = json.loads(raw)
                event_type = message.get("type", "")
                payload = message.get("data") or {}
                if event_type == "ping":
                    await manager.send_socket(websocket, "pong", {"time": time.time()})
                elif event_type == "room.join":
                    room_id = int(payload["room_id"])
                    with engine.connect() as conn:
                        room = fetch_one(conn, select(voice_rooms.c.id).where(voice_rooms.c.id == room_id, voice_rooms.c.status == "live"))
                    if not room:
                        await manager.send_socket(websocket, "error", {"message": "语音房不存在或已关闭"})
                        continue
                    manager.join_room(websocket, room_id)
                    await broadcast_room_state(room_id)
                elif event_type == "room.leave":
                    room_id = int(payload["room_id"])
                    manager.leave_room(websocket, room_id)
                    await broadcast_room_state(room_id)
                elif event_type == "room.mic":
                    room_id = int(payload["room_id"])
                    if not manager.user_in_room(room_id, user_id):
                        raise ValueError("not in room")
                    manager.set_room_mic(room_id, user_id, payload.get("enabled", False))
                    await broadcast_room_state(room_id)
                elif event_type == "room.signal":
                    room_id = int(payload["room_id"])
                    target_id = int(payload["target_id"])
                    if payload.get("kind") not in ("description", "ice"):
                        raise ValueError("invalid signal")
                    if not manager.user_in_room(room_id, user_id) or not manager.user_in_room(room_id, target_id):
                        raise ValueError("peer not in room")
                    forwarded = dict(payload)
                    forwarded["from_user"] = public_user(user)
                    await manager.send_room_user(room_id, target_id, event_type, forwarded)
                elif event_type == "typing":
                    target_id = int(payload["target_id"])
                    await manager.send_user(target_id, "typing", {"user_id": user_id, "typing": bool(payload.get("typing", True))})
                elif event_type.startswith("call."):
                    target_id = int(payload["target_id"])
                    if event_type == "call.invite":
                        with engine.connect() as conn:
                            block = fetch_one(conn, select(user_blocks).where(or_(
                                and_(user_blocks.c.user_id == user_id, user_blocks.c.blocked_id == target_id),
                                and_(user_blocks.c.user_id == target_id, user_blocks.c.blocked_id == user_id),
                            )))
                        if block:
                            await manager.send_socket(websocket, "error", {"message": "当前屏蔽关系下不能发起通话"})
                            continue
                    forwarded = dict(payload)
                    forwarded["from_user"] = public_user(user)
                    await manager.send_user(target_id, event_type, forwarded)
            except (ValueError, TypeError, KeyError, json.JSONDecodeError):
                await manager.send_socket(websocket, "error", {"message": "实时消息格式不正确"})
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(websocket)


# ==================== 商城 / 好感度 / 关系 ====================

@app.get("/api/shop")
async def shop_list(category: Optional[str] = None, user=Depends(get_current_user)):
    """商城全量物品列表，附带当前用户已购状态。"""
    require_user(user)
    with engine.connect() as conn:
        items_query = select(shop_items).where(shop_items.c.available == 1)
        if category:
            items_query = items_query.where(shop_items.c.category == category)
        items = fetch_all(conn, items_query.order_by(shop_items.c.category, shop_items.c.price))
        owned = {row["shop_item_id"]: row for row in fetch_all(conn,
            select(user_items).where(user_items.c.user_id == user["id"])
        )}
    result = []
    for item in items:
        item["owned"] = item["id"] in owned
        item["active"] = owned.get(item["id"], {}).get("is_active", 0) if item["owned"] else 0
        result.append(item)
    return json_ok(result)


@app.post("/api/shop/purchase")
async def shop_purchase(req: ShopPurchaseReq, user=Depends(get_current_user)):
    """用钻石购买商城物品；若 item_key 以 gift_ 开头则也可存入背包作为送礼用。"""
    require_user(user)
    with engine.begin() as conn:
        item = fetch_one(conn, select(shop_items).where(shop_items.c.item_key == req.item_key))
        if not item or item["available"] != 1:
            return json_error("物品不存在或已下架")

        # 自动解锁型称号（需要好感度）
        if item["unlock_favorability"] and item["price"] == 0:
            target = None  # 自动解锁需要指定关系对象；这里改为手动领取
            pass

        existing = conn.execute(
            select(user_items).where(user_items.c.user_id == user["id"], user_items.c.shop_item_id == item["id"])
        ).mappings().first()
        if existing and item["category"] not in ("gift", "bubble", "effect"):
            return json_error("你已拥有该物品")

        if item["price"] > 0:
            balance = conn.execute(select(users.c.coins).where(users.c.id == user["id"])).scalar() or 0
            if balance < item["price"]:
                return json_error("钻石余额不足，请先充值")
            conn.execute(update(users).where(users.c.id == user["id"], users.c.coins >= item["price"]).values(
                coins=users.c.coins - item["price"]
            ))
            conn.execute(insert(wallet_transactions).values(
                user_id=user["id"], kind="shop", coins=-item["price"], note=f"购买 {item['name']}",
            ))

        if existing:
            conn.execute(update(user_items).where(user_items.c.id == existing["id"]).values(
                quantity=user_items.c.quantity + 1
            ))
        else:
            conn.execute(insert(user_items).values(
                user_id=user["id"], shop_item_id=item["id"], source="purchase",
                quantity=1, is_active=1 if item["category"] in ("title", "avatar_frame") else 0,
            ))

        # 如果是称号，自动挂到 user_titles 方便前端展示
        if item["category"] == "title":
            existing_title = conn.execute(
                select(user_titles).where(user_titles.c.user_id == user["id"], user_titles.c.shop_item_id == item["id"])
            ).mappings().first()
            if not existing_title:
                conn.execute(insert(user_titles).values(
                    user_id=user["id"], shop_item_id=item["id"], is_active=1,
                ))
            else:
                conn.execute(update(user_titles).where(user_titles.c.id == existing_title["id"]).values(is_active=1))

        balance = conn.execute(select(users.c.coins).where(users.c.id == user["id"])).scalar()

    await manager.send_user(user["id"], "wallet.update", {"coins": balance})
    return json_ok({"item": item, "coins": balance, "owned": True})


@app.post("/api/shop/redeem")
async def shop_redeem(item_key: str, user=Depends(get_current_user)):
    """用背包中的 item 兑换；当前简单实现：已拥有物品设为启用/停用。"""
    require_user(user)
    with engine.begin() as conn:
        item = fetch_one(conn, select(shop_items).where(shop_items.c.item_key == item_key))
        if not item:
            return json_error("物品不存在")
        existing = conn.execute(
            select(user_items).where(user_items.c.user_id == user["id"], user_items.c.shop_item_id == item["id"])
        ).mappings().first()
        if not existing:
            return json_error("你尚未拥有该物品，请先购买或赠送获得")
        toggle = 0 if existing["is_active"] else 1
        conn.execute(update(user_items).where(user_items.c.id == existing["id"]).values(is_active=toggle))
        if item["category"] == "title":
            conn.execute(update(user_titles).where(
                user_titles.c.user_id == user["id"], user_titles.c.shop_item_id == item["id"]
            ).values(is_active=toggle))
    return json_ok({"item": item, "is_active": bool(toggle)})


@app.get("/api/me/inventory")
async def my_inventory(user=Depends(get_current_user)):
    """当前用户拥有的全部物品 + 称号 + 装扮。"""
    require_user(user)
    with engine.connect() as conn:
        items = fetch_all(conn,
            select(user_items, shop_items.c.item_key, shop_items.c.name, shop_items.c.icon, shop_items.c.category)
            .join(shop_items, user_items.c.shop_item_id == shop_items.c.id)
            .where(user_items.c.user_id == user["id"])
            .order_by(shop_items.c.category, shop_items.c.name)
        )
        titles = fetch_all(conn,
            select(user_titles, shop_items.c.item_key, shop_items.c.name, shop_items.c.icon)
            .join(shop_items, user_titles.c.shop_item_id == shop_items.c.id)
            .where(user_titles.c.user_id == user["id"])
            .order_by(user_titles.c.is_active.desc())
        )
    return json_ok({"items": items, "titles": titles})


# ============ 平台数据统计 & 商城管理（管理员） ============

@app.get("/api/platform/stats")
async def platform_stats(user=Depends(require_admin)):
    """平台整体数据：用户数、礼物总收入、平台收入、商城物品数。"""
    with engine.connect() as conn:
        users_count = conn.execute(select(func.count(users.c.id))).scalar() or 0
        gifts_sent = conn.execute(select(func.count(wallet_transactions.c.id)).where(
            wallet_transactions.c.kind == "gift"
        )).scalar() or 0
        gift_revenue = conn.execute(select(func.coalesce(func.sum(func.abs(wallet_transactions.c.coins)), 0)).where(
            wallet_transactions.c.kind == "gift"
        )).scalar() or 0
        shop_count = conn.execute(select(func.count(shop_items.c.id))).scalar() or 0
        shop_available = conn.execute(select(func.count(shop_items.c.id)).where(shop_items.c.available == 1)).scalar() or 0
        top_gifts = fetch_all(conn, select(room_messages.c.gift_name, func.count(room_messages.c.id).label("count"), func.coalesce(func.sum(room_messages.c.gift_count), 0).label("total")).where(room_messages.c.msg_type == "gift").group_by(room_messages.c.gift_name).order_by(desc("count")).limit(10))
        top_rooms = fetch_all(conn, select(voice_rooms.c.id, voice_rooms.c.topic, func.count(room_messages.c.id).label("gift_count")).join(room_messages, voice_rooms.c.id == room_messages.c.room_id).where(room_messages.c.msg_type == "gift").group_by(voice_rooms.c.id).order_by(desc("gift_count")).limit(5))
    return json_ok({
        "users": users_count,
        "gifts_sent_transactions": gifts_sent,
        "gifts_total_coins": gift_revenue,
        "platform_coins": PLATFORM_WALLET["coins"],
        "shop_items": shop_count,
        "shop_available": shop_available,
        "top_gifts": top_gifts,
        "top_rooms": top_rooms,
    })


@app.get("/api/admin/shop")
async def admin_shop_list(user=Depends(require_admin)):
    """管理员：商城全量物品（含下架）。"""
    with engine.connect() as conn:
        items = fetch_all(conn, select(shop_items).order_by(shop_items.c.category, shop_items.c.price))
    return json_ok(items)


@app.post("/api/admin/shop")
async def admin_shop_create(req: dict, user=Depends(require_admin)):
    """管理员：新增商城物品。"""
    item_key = str(req.get("item_key") or "").strip()[:40]
    name = str(req.get("name") or "").strip()[:80]
    if not item_key or not name:
        return json_error("item_key 和 name 必填")
    category = str(req.get("category") or "gift").strip()[:20]
    if category not in ("gift", "title", "avatar_frame", "bubble", "effect"):
        return json_error("category 必须是 gift/title/avatar_frame/bubble/effect")
    icon = str(req.get("icon") or "🎁").strip()[:32]
    price = int(req.get("price") or 0)
    if price < 0:
        return json_error("price 不能为负数")
    description = str(req.get("description") or "")[:255]
    favorability_boost = int(req.get("favorability_boost") or 0)
    unlock_favorability = int(req.get("unlock_favorability") or 0)
    available = 1 if req.get("available", 1) else 0
    with engine.begin() as conn:
        existing = fetch_one(conn, select(shop_items).where(shop_items.c.item_key == item_key))
        if existing:
            return json_error(f"item_key '{item_key}' 已存在")
        result = conn.execute(insert(shop_items).values(
            item_key=item_key, name=name, icon=icon, category=category,
            price=price, description=description, favorability_boost=favorability_boost,
            unlock_favorability=unlock_favorability, available=available,
        ))
        item = fetch_one(conn, select(shop_items).where(shop_items.c.id == inserted_id(result)))
    return json_ok(item)


@app.put("/api/admin/shop/{item_id}")
async def admin_shop_update(item_id: int, req: dict, user=Depends(require_admin)):
    """管理员：修改商城物品。"""
    with engine.begin() as conn:
        item = fetch_one(conn, select(shop_items).where(shop_items.c.id == item_id))
        if not item:
            return json_error("物品不存在")
        updates = {}
        if "name" in req:
            updates["name"] = str(req["name"])[:80]
        if "icon" in req:
            updates["icon"] = str(req["icon"])[:32]
        if "category" in req and req["category"] in ("gift", "title", "avatar_frame", "bubble", "effect"):
            updates["category"] = str(req["category"])[:20]
        if "price" in req:
            price = int(req["price"])
            if price < 0:
                return json_error("price 不能为负数")
            updates["price"] = price
        if "description" in req:
            updates["description"] = str(req["description"])[:255]
        if "favorability_boost" in req:
            updates["favorability_boost"] = int(req["favorability_boost"])
        if "unlock_favorability" in req:
            updates["unlock_favorability"] = int(req["unlock_favorability"])
        if "available" in req:
            updates["available"] = 1 if req["available"] else 0
        if updates:
            conn.execute(update(shop_items).where(shop_items.c.id == item_id).values(**updates))
        updated = fetch_one(conn, select(shop_items).where(shop_items.c.id == item_id))
    return json_ok(updated)


@app.delete("/api/admin/shop/{item_id}")
async def admin_shop_delete(item_id: int, user=Depends(require_admin)):
    """管理员：下架商城物品（软删除：available=0）。"""
    with engine.begin() as conn:
        item = fetch_one(conn, select(shop_items).where(shop_items.c.id == item_id))
        if not item:
            return json_error("物品不存在")
        conn.execute(update(shop_items).where(shop_items.c.id == item_id).values(available=0))
    return json_ok({"deleted": item_id, "name": item["name"]})


# ---------- 好感度 ----------

@app.get("/api/favorites")
async def list_favorites(user=Depends(get_current_user)):
    """当前用户对所有好友的好感度列表。"""
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn,
            select(user_favorites, users.c.nickname, users.c.avatar)
            .join(users, user_favorites.c.to_user_id == users.c.id)
            .where(user_favorites.c.from_user_id == user["id"])
            .order_by(user_favorites.c.value.desc())
        )
        # 补充双向好感度和关系
        for row in rows:
            mutual_row = conn.execute(
                select(user_favorites.c.value).where(
                    user_favorites.c.from_user_id == row["to_user_id"], user_favorites.c.to_user_id == user["id"]
                )
            ).scalar() or 0
            row["mutual"] = row["value"] + mutual_row
            row["reverse"] = mutual_row
            active_rels = fetch_all(conn,
                select(user_relationships).where(
                    or_(
                        and_(user_relationships.c.user1_id == user["id"], user_relationships.c.user2_id == row["to_user_id"]),
                        and_(user_relationships.c.user1_id == row["to_user_id"], user_relationships.c.user2_id == user["id"]),
                    ),
                    user_relationships.c.status == "active",
                )
            )
            row["relationships"] = [r["rel_type"] for r in active_rels]
            # 计算下一关系还差多少
            row["next_rel"] = None
            for rel_type, meta in sorted(RELATION_TYPES.items(), key=lambda kv: kv[1]["favorability_required"]):
                if row["mutual"] < meta["favorability_required"]:
                    row["next_rel"] = {
                        "type": rel_type,
                        "name": meta["name"],
                        "icon": meta["icon"],
                        "required": meta["favorability_required"],
                        "progress": min(100, row["mutual"] / meta["favorability_required"] * 100),
                        "delta": meta["favorability_required"] - row["mutual"],
                    }
                    break
    return json_ok(rows)


@app.get("/api/favorites/{peer_id}")
async def get_favorite(peer_id: int, user=Depends(get_current_user)):
    """查看与某个具体用户的好感度（双向）。"""
    require_user(user)
    with engine.connect() as conn:
        get_user_required(conn, peer_id)
        a_to_b = fetch_one(conn,
            select(user_favorites).where(
                user_favorites.c.from_user_id == user["id"], user_favorites.c.to_user_id == peer_id
            )
        )
        b_to_a = fetch_one(conn,
            select(user_favorites).where(
                user_favorites.c.from_user_id == peer_id, user_favorites.c.to_user_id == user["id"]
            )
        )
        active_rels = fetch_all(conn,
            select(user_relationships).where(
                or_(
                    and_(user_relationships.c.user1_id == user["id"], user_relationships.c.user2_id == peer_id),
                    and_(user_relationships.c.user1_id == peer_id, user_relationships.c.user2_id == user["id"]),
                ),
                user_relationships.c.status == "active",
            )
        )
    return json_ok({
        "from_me": a_to_b or {"value": 0},
        "to_me": b_to_a or {"value": 0},
        "mutual": (a_to_b or {}).get("value", 0) + (b_to_a or {}).get("value", 0),
        "relationships": active_rels,
        "relation_meta": RELATION_TYPES,
    })


@app.post("/api/favorites/{peer_id}/manual")
async def add_favorite_manual(peer_id: int, payload: dict, user=Depends(get_current_user)):
    """手动增加好感度（调试用：发送一条语音房消息/通话记录后触发）。"""
    require_user(user)
    delta = int(payload.get("delta") or 0)
    source = str(payload.get("source") or "manual")
    if delta <= 0 or delta > 200:
        return json_error("好感度增量必须在 1-200 之间")
    with engine.begin() as conn:
        get_user_required(conn, peer_id)
        new_fav = adjust_favorability(conn, user["id"], peer_id, delta, gift=False)
        rel_info = update_relationship_on_favorability(conn, user["id"], peer_id)
    return json_ok({"favorability": new_fav, "delta": delta, "source": source, "relationships": rel_info})


# ---------- 关系 ----------

@app.get("/api/relationships")
async def list_relationships(user=Depends(get_current_user)):
    """当前用户所有已建立的绑定关系。"""
    require_user(user)
    with engine.connect() as conn:
        rows = fetch_all(conn,
            select(user_relationships, users.c.id.label("peer_id"), users.c.nickname, users.c.avatar)
            .join(users, or_(
                and_(user_relationships.c.user1_id == users.c.id, user_relationships.c.user2_id == user["id"]),
                and_(user_relationships.c.user2_id == users.c.id, user_relationships.c.user1_id == user["id"]),
            ))
            .where(or_(
                and_(user_relationships.c.user1_id == user["id"], user_relationships.c.user2_id != user["id"]),
                and_(user_relationships.c.user2_id == user["id"], user_relationships.c.user1_id != user["id"]),
            ), user_relationships.c.status == "active")
            .order_by(user_relationships.c.bound_at.desc())
        )
    for row in rows:
        rel = RELATION_TYPES.get(row["rel_type"], {})
        row["rel_name"] = rel.get("name", row["rel_type"])
        row["rel_icon"] = rel.get("icon", "💞")
        row["rel_color"] = rel.get("color", "#ec4899")
    return json_ok(rows)


@app.post("/api/relationships/bind")
async def bind_relationship(req: RelationshipReq, user=Depends(get_current_user)):
    """主动申请/确认绑定关系；双方必须已达到好感度阈值。"""
    require_user(user)
    meta = RELATION_TYPES.get(req.rel_type)
    if not meta:
        return json_error(f"未知关系类型：{req.rel_type}")
    with engine.begin() as conn:
        get_user_required(conn, req.target_id)
        if req.target_id == user["id"]:
            return json_error("不能和自己绑定关系")

        # 计算双向好感度总和
        a_to_b = conn.execute(
            select(func.coalesce(func.sum(user_favorites.c.value), 0)).where(
                user_favorites.c.from_user_id == user["id"], user_favorites.c.to_user_id == req.target_id
            )
        ).scalar() or 0
        b_to_a = conn.execute(
            select(func.coalesce(func.sum(user_favorites.c.value), 0)).where(
                user_favorites.c.from_user_id == req.target_id, user_favorites.c.to_user_id == user["id"]
            )
        ).scalar() or 0
        mutual = a_to_b + b_to_a
        if mutual < meta["favorability_required"]:
            return json_error(f"双方好感度仅 {mutual}，需要 {meta['favorability_required']} 才能绑定为「{meta['name']}」")

        # 检查对方是否也愿意（简化：直接绑定，后续可加申请流程）
        low, high = sorted([user["id"], req.target_id])
        existing = conn.execute(
            select(user_relationships).where(
                user_relationships.c.user1_id == low, user_relationships.c.user2_id == high,
                user_relationships.c.rel_type == req.rel_type,
            )
        ).mappings().first()

        if existing and existing["status"] == "active":
            return json_error("你们已经是这种关系了")

        if existing:
            conn.execute(update(user_relationships).where(user_relationships.c.id == existing["id"]).values(
                favorability=mutual, status="active", bound_at=datetime.now(), broken_at=None,
            ))
        else:
            conn.execute(insert(user_relationships).values(
                user1_id=low, user2_id=high, rel_type=req.rel_type,
                favorability=mutual, status="active", bound_at=datetime.now(),
            ))

        unlock_item_for_pair(conn, req.rel_type, low, high)

    # 推送双方绑定通知
    await manager.send_user(user["id"], "relationship.bound", {
        "with_user_id": req.target_id, "rel_type": req.rel_type,
        "mutual_favorability": mutual, "icon": meta["icon"], "name": meta["name"],
    })
    await manager.send_user(req.target_id, "relationship.bound", {
        "with_user_id": user["id"], "rel_type": req.rel_type,
        "mutual_favorability": mutual, "icon": meta["icon"], "name": meta["name"],
    })

    return json_ok({"rel_type": req.rel_type, "rel_name": meta["name"], "rel_icon": meta["icon"], "mutual_favorability": mutual})


@app.post("/api/relationships/{rel_type}/break")
async def break_relationship(rel_type: str, payload: dict, user=Depends(get_current_user)):
    target_id = int(payload.get("target_id") or 0)
    require_user(user)
    if not target_id:
        return json_error("缺少 target_id")
    meta = RELATION_TYPES.get(rel_type)
    if not meta:
        return json_error(f"未知关系类型：{rel_type}")
    with engine.begin() as conn:
        low, high = sorted([user["id"], target_id])
        conn.execute(update(user_relationships).where(
            user_relationships.c.user1_id == low, user_relationships.c.user2_id == high,
            user_relationships.c.rel_type == rel_type, user_relationships.c.status == "active",
        ).values(status="broken", broken_at=datetime.now()))
    return json_ok({"status": "broken", "rel_type": rel_type})


@app.get("/api/rel-types")
async def rel_types():
    """返回全部关系类型及其解锁条件。"""
    return json_ok(RELATION_TYPES)


@app.get("/{full_path:path}")
async def serve_static(full_path: str):
    allowed = {".html", ".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webmanifest"}
    candidate = (STATIC_DIR / full_path).resolve()
    try:
        candidate.relative_to(STATIC_DIR)
    except ValueError:
        raise HTTPException(status_code=403, detail="禁止访问")
    if full_path and candidate.is_file() and candidate.suffix.lower() in allowed:
        return FileResponse(str(candidate))
    return FileResponse(str(STATIC_DIR / "index.html"))


if __name__ == "__main__":
    import uvicorn
    print("=" * 54)
    print("圈圈语音社 FastAPI 全功能后端")
    print("数据库:", engine.dialect.name, DATABASE_URL)
    print("本地访问: http://127.0.0.1:8090")
    print("API 文档: http://127.0.0.1:8090/docs")
    print("=" * 54)
    uvicorn.run(app, host="0.0.0.0", port=8090, log_level="info")
